package space.kaise.zeno

import android.media.*
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.*
import kotlinx.coroutines.*

/** PCM is kept only in memory. Never records while playback is active. */
class VoiceEngine {
    private val recording = AtomicBoolean(false)
    private val playing = AtomicBoolean(false)

    fun finishRecording() {
        recording.set(false)
    }

    fun stop() {
        recording.set(false)
        playing.set(false)
    }

    suspend fun record(onLevel: (Float, Float) -> Unit): ByteArray =
        withContext(Dispatchers.IO) {
            val rate = 16000
            val minimum =
                AudioRecord.getMinBufferSize(
                    rate,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,
                )
            check(minimum > 0) { "O microfone está indisponível." }
            val mic =
                AudioRecord(
                    MediaRecorder.AudioSource.VOICE_RECOGNITION,
                    rate,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,
                    max(minimum, 3200),
                )
            val output = ByteArrayOutputStream()
            val samples = ShortArray(640)
            var heard = false
            var silent = 0
            var frames = 0
            try {
                check(mic.state == AudioRecord.STATE_INITIALIZED) {
                    "Não foi possível abrir o microfone."
                }
                recording.set(true)
                mic.startRecording()
                while (recording.get() && isActive && frames < 750) {
                    val count = mic.read(samples, 0, samples.size)
                    check(count > 0) { "O microfone foi interrompido." }
                    val (rms, tone) = signal(samples, count, rate)
                    withContext(Dispatchers.Main) { onLevel((rms * 7).coerceIn(0f, 1f), tone) }
                    if (rms > .018f) {
                        heard = true
                        silent = 0
                    } else silent++
                    val bytes = ByteBuffer.allocate(count * 2).order(ByteOrder.LITTLE_ENDIAN)
                    for (i in 0 until count) bytes.putShort(samples[i])
                    output.write(bytes.array())
                    frames++
                    if (heard && silent > 30 || !heard && frames > 200) break
                }
                ensureActive()
                check(heard) { "Não ouvi sua voz. Toque na bolha e tente novamente." }
                wav(output.toByteArray(), rate)
            } finally {
                recording.set(false)
                runCatching { mic.stop() }
                mic.release()
                withContext(NonCancellable + Dispatchers.Main) { onLevel(0f, 0f) }
            }
        }

    suspend fun play(wav: ByteArray, onLevel: (Float, Float) -> Unit) =
        withContext(Dispatchers.IO) {
            val decoded = decodeWave(wav)
            val bytes = decoded.first
            val rate = decoded.second
            val audio =
                AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ASSISTANT)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setSampleRate(rate)
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(
                        max(
                            AudioTrack.getMinBufferSize(
                                rate,
                                AudioFormat.CHANNEL_OUT_MONO,
                                AudioFormat.ENCODING_PCM_16BIT,
                            ),
                            rate / 5,
                        )
                    )
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build()
            try {
                playing.set(true)
                audio.play()
                var position = 0
                while (playing.get() && isActive && position < bytes.size) {
                    val count = min(rate / 25 * 2, bytes.size - position)
                    val shorts = ShortArray(count / 2)
                    ByteBuffer.wrap(bytes, position, count)
                        .order(ByteOrder.LITTLE_ENDIAN)
                        .asShortBuffer()
                        .get(shorts)
                    val (rms, tone) = signal(shorts, shorts.size, rate)
                    withContext(Dispatchers.Main) { onLevel((rms * 5).coerceIn(0f, 1f), tone) }
                    val written = audio.write(bytes, position, count, AudioTrack.WRITE_BLOCKING)
                    check(written > 0) { "Não foi possível reproduzir a voz." }
                    position += written
                }
                // Wait for remaining buffered frames before the next microphone turn.
                while (
                    playing.get() && isActive && audio.playbackHeadPosition.toLong() < position / 2
                ) delay(20)
            } finally {
                playing.set(false)
                runCatching { audio.stop() }
                audio.release()
                withContext(NonCancellable + Dispatchers.Main) { onLevel(0f, 0f) }
            }
        }
}

fun signal(samples: ShortArray, count: Int, rate: Int): Pair<Float, Float> {
    if (count == 0) return 0f to 0f
    var sum = 0.0
    var crossings = 0
    for (i in 0 until count) {
        val v = samples[i] / 32768.0
        sum += v * v
        if (i > 0 && samples[i] >= 0 && samples[i - 1] < 0) crossings++
    }
    // Zero-crossing frequency is an estimate of timbre, not a claim of exact pitch.
    return sqrt(sum / count).toFloat() to
        (crossings.toFloat() * rate / count / 1000).coerceIn(0f, 1f)
}

fun wav(pcm: ByteArray, rate: Int): ByteArray {
    val b = ByteBuffer.allocate(44 + pcm.size).order(ByteOrder.LITTLE_ENDIAN)
    b.put("RIFF".toByteArray())
    b.putInt(pcm.size + 36)
    b.put("WAVEfmt ".toByteArray())
    b.putInt(16)
    b.putShort(1)
    b.putShort(1)
    b.putInt(rate)
    b.putInt(rate * 2)
    b.putShort(2)
    b.putShort(16)
    b.put("data".toByteArray())
    b.putInt(pcm.size)
    b.put(pcm)
    return b.array()
}

fun decodeWave(bytes: ByteArray): Pair<ByteArray, Int> {
    require(
        bytes.size in 44..12000000 && String(bytes, 0, 4) == "RIFF" && String(bytes, 8, 4) == "WAVE"
    ) {
        "Áudio inválido."
    }
    val b = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
    var rate = 0
    var position = 12
    while (position + 8 <= bytes.size) {
        val tag = String(bytes, position, 4)
        val length = b.getInt(position + 4)
        require(length >= 0 && length <= bytes.size - position - 8)
        if (tag == "fmt ") {
            require(
                length >= 16 &&
                    b.getShort(position + 8).toInt() == 1 &&
                    b.getShort(position + 10).toInt() == 1 &&
                    b.getShort(position + 22).toInt() == 16
            )
            rate = b.getInt(position + 12)
            require(rate in 8000..48000)
        }
        if (tag == "data") {
            require(rate > 0 && length % 2 == 0)
            return bytes.copyOfRange(position + 8, position + 8 + length) to rate
        }
        position += 8 + length + (length % 2)
    }
    error("Áudio sem dados PCM.")
}
