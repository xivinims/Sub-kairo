package space.kaise.zeno

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.*
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.*
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.*
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.input.*
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import kotlinx.coroutines.delay

val Heading = FontFamily.SansSerif
val Body = FontFamily.SansSerif
val Code = FontFamily.Monospace
private val Dark =
    darkColorScheme(
        primary = Color.White,
        onPrimary = Color.Black,
        secondary = Color(0xFF94B9FF),
        secondaryContainer = Color(0xFF222225),
        onSecondaryContainer = Color(0xFFF4F4F5),
        background = Color.Black,
        onBackground = Color(0xFFF4F4F5),
        surface = Color(0xFF111113),
        surfaceVariant = Color(0xFF222225),
        onSurface = Color(0xFFF4F4F5),
        onSurfaceVariant = Color(0xFF9999A1),
        outline = Color(0xFF36363C),
        error = Color(0xFFFF8A87),
    )
private val Light =
    lightColorScheme(
        primary = Color(0xFF121216),
        onPrimary = Color.White,
        secondary = Color(0xFF315EA8),
        secondaryContainer = Color(0xFFEEEEF2),
        onSecondaryContainer = Color(0xFF121216),
        background = Color(0xFFFAFAFC),
        surface = Color.White,
        surfaceVariant = Color(0xFFEEEEF2),
        onSurfaceVariant = Color(0xFF66666E),
        outline = Color(0xFFDCDCE3),
    )

@Composable
fun ZenoTheme(appearance: String = "Escuro", content: @Composable () -> Unit) {
    val dark = appearance == "Escuro" || appearance == "Sistema" && isSystemInDarkTheme()
    MaterialTheme(
        colorScheme = if (dark) Dark else Light,
        typography =
            Typography(
                displayLarge =
                    TextStyle(
                        fontFamily = Heading,
                        fontWeight = FontWeight.Bold,
                        fontSize = 72.sp,
                        letterSpacing = (-3).sp,
                    ),
                headlineLarge =
                    TextStyle(
                        fontFamily = Heading,
                        fontWeight = FontWeight.Bold,
                        fontSize = 36.sp,
                        lineHeight = 40.sp,
                        letterSpacing = (-1).sp,
                    ),
                headlineMedium =
                    TextStyle(
                        fontFamily = Heading,
                        fontWeight = FontWeight.Medium,
                        fontSize = 27.sp,
                        lineHeight = 34.sp,
                    ),
                titleLarge =
                    TextStyle(
                        fontFamily = Heading,
                        fontWeight = FontWeight.Medium,
                        fontSize = 22.sp,
                    ),
                titleMedium =
                    TextStyle(
                        fontFamily = Body,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 16.sp,
                    ),
                bodyLarge = TextStyle(fontFamily = Body, fontSize = 16.sp, lineHeight = 26.sp),
                bodyMedium = TextStyle(fontFamily = Body, fontSize = 14.sp, lineHeight = 22.sp),
                labelLarge =
                    TextStyle(
                        fontFamily = Body,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 15.sp,
                    ),
                labelSmall = TextStyle(fontFamily = Body, fontSize = 11.sp, letterSpacing = .5.sp),
            ),
        content = content,
    )
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { ZenoApp() }
    }
}

@Composable
fun ZenoApp(vm: ZenoModel = viewModel()) {
    val s by vm.state.collectAsStateWithLifecycle()
    val view = LocalView.current
    LaunchedEffect(s.haptics) { view.isHapticFeedbackEnabled = s.haptics }
    LaunchedEffect(s.authenticated) {
        if (s.authenticated)
            while (true) {
                vm.refresh()
                delay(60000)
            }
    }
    BackHandler(s.settings || s.drawer) { if (s.settings) vm.settings(false) else vm.drawer(false) }
    ZenoTheme(s.appearance) {
        Surface(Modifier.fillMaxSize()) {
            Crossfade(
                when {
                    !s.authenticated -> "auth"
                    s.settings -> "settings"
                    s.drawer -> "history"
                    else -> "chat"
                },
                label = "navigation",
            ) { route ->
                when (route) {
                    "auth" -> AuthScreen(s, vm)
                    "settings" -> SettingsScreen(s, vm)
                    "history" -> HistoryScreen(s, vm)
                    else -> ChatScreen(s, vm)
                }
            }
        }
    }
}

@Composable
fun Star(modifier: Modifier = Modifier, color: Color = MaterialTheme.colorScheme.onBackground) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val p =
            Path().apply {
                moveTo(w * .5f, 0f)
                cubicTo(w * .56f, h * .36f, w * .64f, h * .44f, w, h * .5f)
                cubicTo(w * .64f, h * .56f, w * .56f, h * .64f, w * .5f, h)
                cubicTo(w * .44f, h * .64f, w * .36f, h * .56f, 0f, h * .5f)
                cubicTo(w * .36f, h * .44f, w * .44f, h * .36f, w * .5f, 0f)
                close()
            }
        drawPath(p, color)
    }
}

@Composable
fun PreviewBadge() {
    Text(
        "PRÉVIA OFFLINE · SERVIÇOS DESCONECTADOS",
        Modifier.fillMaxWidth().padding(vertical = 8.dp),
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        textAlign = TextAlign.Center,
    )
}

@Composable
fun Notice(text: String, error: Boolean = false) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color =
            (if (error) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.secondary)
                .copy(alpha = .10f),
    ) {
        Text(
            text,
            Modifier.fillMaxWidth().padding(14.dp),
            style = MaterialTheme.typography.bodyMedium,
            color =
                if (error) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.secondary,
        )
    }
}

@Composable
fun Primary(text: String, busy: Boolean = false, enabled: Boolean = true, action: () -> Unit) {
    val view = LocalView.current
    Button(
        {
            view.performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_TAP)
            action()
        },
        Modifier.fillMaxWidth().height(56.dp),
        enabled = enabled && !busy,
        shape = CircleShape,
    ) {
        if (busy)
            CircularProgressIndicator(
                Modifier.size(22.dp),
                color = MaterialTheme.colorScheme.onPrimary,
                strokeWidth = 2.dp,
            )
        else Text(text, fontSize = 17.sp)
    }
}

@Composable
fun CircleButton(icon: ImageVector, label: String, action: () -> Unit) {
    IconButton(
        action,
        Modifier.size(46.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surfaceVariant),
    ) {
        Icon(icon, label, Modifier.size(22.dp))
    }
}

@Composable
fun Field(
    value: String,
    change: (String) -> Unit,
    hint: String,
    type: KeyboardType = KeyboardType.Text,
    secret: Boolean = false,
    code: Boolean = false,
) {
    var visible by remember { mutableStateOf(false) }
    TextField(
        value,
        change,
        Modifier.fillMaxWidth(),
        singleLine = true,
        shape = RoundedCornerShape(20.dp),
        placeholder = { Text(hint) },
        keyboardOptions = KeyboardOptions(keyboardType = type),
        visualTransformation =
            if (secret && !visible) PasswordVisualTransformation() else VisualTransformation.None,
        textStyle =
            MaterialTheme.typography.bodyLarge.copy(
                fontFamily = if (code) Code else Body,
                fontSize = if (code) 26.sp else 16.sp,
                letterSpacing = if (code) 10.sp else 0.sp,
            ),
        trailingIcon =
            if (secret) {
                {
                    TextButton({ visible = !visible }) {
                        Text(if (visible) "Ocultar" else "Ver", fontSize = 12.sp)
                    }
                }
            } else null,
        colors =
            TextFieldDefaults.colors(
                focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                focusedIndicatorColor = Color.Transparent,
                unfocusedIndicatorColor = Color.Transparent,
            ),
    )
}

@Composable
fun GoogleButton(s: State, vm: ZenoModel) {
    val context = LocalContext.current
    Row(
        Modifier.padding(vertical = 22.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        HorizontalDivider(Modifier.weight(1f))
        Text("ou", color = MaterialTheme.colorScheme.onSurfaceVariant)
        HorizontalDivider(Modifier.weight(1f))
    }
    OutlinedButton(
        { vm.google(context) },
        Modifier.fillMaxWidth().height(56.dp),
        enabled = !s.busy,
        shape = CircleShape,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
    ) {
        Text("G", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.width(12.dp))
        Text("Continuar com Google")
    }
}

@Composable
fun Welcome(s: State, vm: ZenoModel) {
    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        Column(
            Modifier.fillMaxSize().safeDrawingPadding().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            if (BuildConfig.DEMO) PreviewBadge()
            Spacer(Modifier.height(36.dp))
            Text(
                "Mammon",
                style = MaterialTheme.typography.displayLarge,
                color = MaterialTheme.colorScheme.onBackground,
            )
            Text(
                "UM ESPAÇO PARA SUAS IDEIAS",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                letterSpacing = 2.sp,
            )
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Star(Modifier.size(88.dp), MaterialTheme.colorScheme.onBackground)
            }
            Text(
                "Pense alto.",
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onBackground,
            )
            Text(
                "Pergunte, crie e descubra novas possibilidades.",
                Modifier.padding(top = 10.dp, bottom = 28.dp),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                style = MaterialTheme.typography.bodyMedium,
            )
            Primary("Criar conta") { vm.step(Step.EMAIL) }
            Spacer(Modifier.height(12.dp))
            Button(
                { vm.step(Step.LOGIN) },
                Modifier.fillMaxWidth().height(56.dp),
                shape = CircleShape,
                colors =
                    ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant,
                        contentColor = MaterialTheme.colorScheme.onSurface,
                    ),
            ) {
                Text("Fazer login", fontSize = 17.sp)
            }
            if (BuildConfig.DEMO)
                TextButton(vm::demo) { Text("Explorar a prévia", color = Color(0xFF94B9FF)) }
            else Spacer(Modifier.height(18.dp))
        }
    }
}

@Composable
fun AuthScreen(s: State, vm: ZenoModel) {
    if (s.step == Step.WELCOME) {
        Welcome(s, vm)
        return
    }
    var help by remember { mutableStateOf(false) }
    BackHandler(!s.busy) { vm.back() }
    Column(
        Modifier.fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .safeDrawingPadding()
            .imePadding()
            .padding(horizontal = 24.dp)
            .verticalScroll(rememberScrollState())
    ) {
        if (BuildConfig.DEMO) PreviewBadge()
        Row(
            Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 28.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(vm::back, enabled = !s.busy) { Icon(AppIcons.ArrowBack, "Voltar") }
            Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                val index =
                    when (s.step) {
                        Step.EMAIL -> 0
                        Step.PASSWORD -> 1
                        Step.CODE -> 2
                        else -> 3
                    }
                repeat(4) {
                    Box(
                        Modifier.size(21.dp, 3.dp)
                            .clip(CircleShape)
                            .background(
                                if (it <= index) MaterialTheme.colorScheme.onBackground
                                else MaterialTheme.colorScheme.outline
                            )
                    )
                }
            }
            IconButton({ help = true }) { Icon(AppIcons.Info, "Ajuda") }
        }
        Text(
            when (s.step) {
                Step.EMAIL -> "Crie sua\nconta Mammon."
                Step.CODE -> "Verifique seu\ne-mail."
                Step.PASSWORD -> "Só sua.\nBem protegida."
                Step.PROFILE -> "Como podemos\nchamar você?"
                Step.LOGIN -> "Bom ter\nvocê de volta."
                else -> "Vamos recuperar\nsua senha."
            },
            style = MaterialTheme.typography.headlineLarge,
        )
        Spacer(Modifier.height(14.dp))
        Text(
            when (s.step) {
                Step.EMAIL -> "Uma conversa pode mudar tudo. Comece pelo seu e-mail."
                Step.CODE -> "Abra o link de verificação enviado para ${s.email} e volte ao Mammon."
                Step.PASSWORD -> "Crie uma senha com pelo menos 10 caracteres, letras e números."
                Step.PROFILE ->
                    "Mais um pouco sobre você, para deixar a experiência com a sua cara."
                Step.LOGIN -> "Suas ideias continuam de onde pararam."
                else -> "Informe seu e-mail para receber as instruções."
            },
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(28.dp))
        s.error?.let {
            Notice(it, true)
            Spacer(Modifier.height(16.dp))
        }
        s.notice?.let {
            Notice(it)
            Spacer(Modifier.height(16.dp))
        }
        when (s.step) {
            Step.EMAIL -> {
                Field(s.email, vm::email, "Seu e-mail", KeyboardType.Email)
                TextButton({ vm.step(Step.LOGIN) }, Modifier.padding(vertical = 10.dp)) {
                    Text(
                        "Já tem uma conta? Entre aqui.",
                        color = MaterialTheme.colorScheme.secondary,
                    )
                }
                Primary(
                    if (BuildConfig.DEMO) "Testar cadastro" else "Continuar",
                    s.busy,
                    s.email.isNotBlank(),
                    vm::requestCode,
                )
                GoogleButton(s, vm)
            }
            Step.CODE -> {
                Surface(
                    shape = RoundedCornerShape(22.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                ) {
                    Column(Modifier.fillMaxWidth().padding(18.dp)) {
                        Text("Link enviado", style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "Toque no link recebido por e-mail. Depois volte aqui e confirme a verificação.",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
                Spacer(Modifier.height(24.dp))
                Primary("Já verifiquei meu e-mail", s.busy, true, vm::verifyEmail)
                TextButton(
                    vm::resendVerification,
                    Modifier.align(Alignment.CenterHorizontally),
                    enabled = s.cooldown == 0 && !s.busy,
                ) {
                    Text(
                        if (s.cooldown > 0) "Reenviar em ${s.cooldown}s"
                        else "Não chegou? Reenviar link"
                    )
                }
            }
            Step.PASSWORD -> {
                var password by remember { mutableStateOf("") }
                var confirm by remember { mutableStateOf("") }
                Field(password, { password = it }, "Crie sua senha", KeyboardType.Password, true)
                Spacer(Modifier.height(12.dp))
                Field(confirm, { confirm = it }, "Confirme a senha", KeyboardType.Password, true)
                Spacer(Modifier.height(28.dp))
                Primary(
                    "Criar conta",
                    s.busy,
                    password.isNotBlank() && confirm.isNotBlank(),
                ) {
                    vm.password(password, confirm)
                }
            }
            Step.PROFILE -> {
                var name by remember { mutableStateOf(s.profile.name) }
                var age by remember { mutableStateOf("") }
                var gender by remember { mutableStateOf("Prefiro não informar") }
                var expanded by remember { mutableStateOf(false) }
                Field(name, { name = it.take(60) }, "Seu nome")
                Spacer(Modifier.height(12.dp))
                Field(
                    age,
                    { age = it.filter(Char::isDigit).take(3) },
                    "Sua idade",
                    KeyboardType.Number,
                )
                Spacer(Modifier.height(12.dp))
                Box {
                    Surface(
                        onClick = { expanded = true },
                        shape = RoundedCornerShape(20.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                    ) {
                        Column(Modifier.fillMaxWidth().padding(18.dp)) {
                            Text(
                                "Gênero · opcional",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                            Text("$gender  ⌄")
                        }
                    }
                    DropdownMenu(expanded, { expanded = false }) {
                        listOf(
                                "Feminino",
                                "Masculino",
                                "Não binário",
                                "Outro",
                                "Prefiro não informar",
                            )
                            .forEach { v ->
                                DropdownMenuItem(
                                    { Text(v) },
                                    {
                                        gender = v
                                        expanded = false
                                    },
                                )
                            }
                    }
                }
                Text(
                    "Disponível a partir de 13 anos. Gênero é opcional.",
                    Modifier.padding(vertical = 16.dp),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Primary("Começar a conversar", s.busy, name.isNotBlank() && age.isNotBlank()) {
                    vm.profile(name, age, gender)
                }
            }
            Step.LOGIN -> {
                var password by remember { mutableStateOf("") }
                Field(s.email, vm::email, "Seu e-mail", KeyboardType.Email)
                Spacer(Modifier.height(12.dp))
                Field(password, { password = it }, "Sua senha", KeyboardType.Password, true)
                TextButton({ vm.step(Step.RESET) }, Modifier.padding(vertical = 8.dp)) {
                    Text("Esqueci minha senha", color = MaterialTheme.colorScheme.secondary)
                }
                Primary("Entrar", s.busy, s.email.isNotBlank() && password.isNotBlank()) {
                    vm.login(password)
                }
                GoogleButton(s, vm)
            }
            Step.RESET -> {
                Field(s.email, vm::email, "Seu e-mail", KeyboardType.Email)
                Spacer(Modifier.height(24.dp))
                Primary("Enviar instruções", s.busy, s.email.isNotBlank(), vm::reset)
            }
            else -> Unit
        }
        Spacer(Modifier.height(36.dp))
    }
    if (help)
        AlertDialog(
            onDismissRequest = { help = false },
            title = { Text("Um passo de cada vez.") },
            text = {
                Text(
                    "O código vale por 10 minutos e permite até 5 tentativas. Confira também a pasta de spam. Com Google, a confirmação acontece no próprio Google."
                )
            },
            confirmButton = { TextButton({ help = false }) { Text("Entendi") } },
        )
}

@Composable
fun Thinking(image: Boolean) {
    var dots by remember { mutableIntStateOf(1) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(480)
            dots = dots % 3 + 1
        }
    }
    Row(
        Modifier.padding(vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Star(Modifier.size(20.dp), MaterialTheme.colorScheme.secondary)
        Text(
            (if (image) "Criando imagem" else "Pensando") + ".".repeat(dots),
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
fun Suggestion(text: String, action: () -> Unit) {
    Surface(onClick = action, shape = CircleShape, color = MaterialTheme.colorScheme.surface) {
        Text(
            text,
            Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
            style = MaterialTheme.typography.bodyMedium,
        )
    }
}

@Composable
fun UserBubble(text: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
        Surface(
            shape = RoundedCornerShape(24.dp, 24.dp, 7.dp, 24.dp),
            color = MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier.widthIn(max = 310.dp),
        ) {
            Text(text, Modifier.padding(horizontal = 18.dp, vertical = 13.dp))
        }
    }
}

@Composable
fun MessageView(m: Message, vm: ZenoModel) {
    val clipboard = LocalClipboardManager.current
    if (m.role == "user") UserBubble(m.text)
    else
        Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Star(Modifier.size(20.dp))
                Text("Mammon", style = MaterialTheme.typography.labelLarge)
            }
            if (m.kind == "image") GeneratedImage(m.imagePath, vm)
            else {
                if (m.summary.isNotBlank()) ProgressPanel("done", m.summary, false)
                Markdown(m.text)
                if (m.files.isNotEmpty())
                    Surface(
                        onClick = { vm.workspace(true) },
                        shape = RoundedCornerShape(18.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                    ) {
                        Row(
                            Modifier.fillMaxWidth().padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Icon(AppIcons.Description, null, Modifier.size(22.dp))
                            Spacer(Modifier.width(12.dp))
                            Text("${m.files.size} arquivos criados", Modifier.weight(1f))
                            Icon(AppIcons.ChevronRight, null, Modifier.size(18.dp))
                        }
                    }
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    IconButton({ clipboard.setText(AnnotatedString(m.text)) }) {
                        Icon(
                            AppIcons.ContentCopy,
                            "Copiar resposta",
                            Modifier.size(21.dp),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    val context = LocalContext.current
                    IconButton({
                        context.startActivity(
                            Intent.createChooser(
                                Intent(Intent.ACTION_SEND)
                                    .setType("text/plain")
                                    .putExtra(Intent.EXTRA_TEXT, m.text),
                                "Compartilhar resposta",
                            )
                        )
                    }) {
                        Icon(
                            AppIcons.IosShare,
                            "Compartilhar resposta",
                            Modifier.size(21.dp),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    IconButton({ vm.speakMessage(m) }) {
                        Icon(
                            AppIcons.VolumeUp,
                            "Ouvir resposta",
                            Modifier.size(22.dp),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
        }
}

@Composable
fun GeneratedImage(path: String, vm: ZenoModel) {
    var bytes by remember(path) { mutableStateOf<ByteArray?>(null) }
    var failed by remember { mutableStateOf(false) }
    var attempt by remember { mutableIntStateOf(0) }
    LaunchedEffect(path, attempt) {
        failed = false
        try {
            bytes = vm.image(path)
        } catch (_: Exception) {
            failed = true
        }
    }
    Surface(shape = RoundedCornerShape(24.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
        if (bytes != null)
            AsyncImage(
                bytes,
                "Imagem gerada a partir do seu pedido",
                Modifier.fillMaxWidth().aspectRatio(1f),
            )
        else
            Box(Modifier.fillMaxWidth().aspectRatio(1f), contentAlignment = Alignment.Center) {
                if (failed) TextButton({ attempt++ }) { Text("Carregar imagem novamente") }
                else CircularProgressIndicator(Modifier.size(28.dp), strokeWidth = 2.dp)
            }
    }
}
