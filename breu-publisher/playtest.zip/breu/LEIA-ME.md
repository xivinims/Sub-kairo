# BREU — Playtest 01

Versão de desenvolvimento de um jogo cooperativo de perseguição e resgate, criada a partir desta conversa. **Não é uma versão final nem foi executada no cliente Roblox nesta sessão.**

## Abrir

Abra `BREU-Playtest-01.rbxlx` no Roblox Studio. O arquivo já contém os scripts, mapas, lobby e interfaces; não é um instalador para colar na Command Bar. Inicie Play e selecione **Entrar na próxima rodada**. A contagem do lobby é de 25 segundos. Entradas durante uma partida aguardam a próxima.

No celular, o arquivo precisa ser publicado em uma experiência Roblox antes de poder ser jogado pelo aplicativo. Este pacote não foi publicado e não substitui nenhuma experiência existente.

## Partida

Até 12 participantes como alvo de capacidade. Restaure três quadros sorteados entre os pontos do mapa; no teste solo, dois. Quando a energia voltar, um dos dois resgates abre por 65 segundos. Escape e leve os companheiros. Quadros, condições de visibilidade e velocidade do perseguidor variam entre rodadas.

O Vigia patrulha e usa visão e barulho de corrida para localizar jogadores. Calcula caminhos, tenta saltar quando fica preso e quebra barricadas próximas. Um clarão frontal pode desorientá-lo por três segundos. O clarão recarrega em 24 segundos.

Jogadores caídos têm 42 segundos para receber ajuda. Um companheiro pode ajudar durante quatro segundos ou carregar o jogador até o resgate. A queda de todos os sobreviventes encerra a partida. O modo solo tem uma única segunda chance automática para permitir testar o ciclo sem outro jogador.

Interações longas exigem ficar parado; mover-se, perder a linha de visão ou cancelar interrompe o progresso. Energia restaurada e socorros rendem fichas mesmo quando o jogador não escapa. As fichas são contagem de progresso; não há uma loja fictícia ou compras implementadas.

## Controles

| Ação | Computador | Controle | Celular |
|---|---|---|---|
| Correr | Segurar Shift | L3 alterna | ⇧ alterna |
| Agachar / andar devagar | C | B | ↓ |
| Clarão | F | Y | ✦ |
| Ajudar companheiro próximo | R | Direcional para cima | + |
| Carregar / soltar companheiro | G | Direcional para baixo | ↥ |
| Interagir | E | X | Prompt junto ao objeto |
| Cancelar ação | Backspace ou mover | Mover | × no progresso ou mover |
| Configurações | M ou engrenagem | Interface | Engrenagem |

O movimento e o pulo normais são do controle padrão do Roblox. Agachar nesta versão reduz velocidade; ainda não tem um conjunto próprio de animações. O Vigia usa movimentação procedural simples.

## Conteúdo

- **Distrito do Canal:** cenário urbano original modular, oito edifícios com interiores, rotas por telhados, escadas externas, barricadas e caixotes empurráveis. Arte de desenvolvimento, ainda precisa de avaliação visual no Roblox.
- **Reserva abandonada:** geometria estática extraída da pasta `Workspace.Map` do arquivo enviado. Utiliza seus marcadores de spawn. Toda a lógica antiga foi removida.
- **Terminal:** lobby próprio com plantas, luminária e maleta extraídas do modelo do hotel. Não importei o hotel inteiro nem seus scripts e CSG. O leitor binário exclui unions; esses elementos não são utilizados no novo lobby.
- HUD em PT-BR, fila, tela inicial, transição antes da partida, saúde, fôlego, progresso, resultados, modo espectador e ajustes de efeitos, sombras, áudio e campo de visão. Ajustes duram durante a sessão.
- Mapas ficam no ServerStorage até entrar na rotação; apenas um é colocado no Workspace. Streaming ativado e efeitos reduzidos por padrão quando há controle de toque. Isso **não comprova desempenho em aparelhos de 3 GB**.

## Validação feita

- Sintaxe dos seis arquivos Lua, usando um compilador Lua compatível com a sintaxe utilizada. Não equivale a análise de tipos ou execução Luau no Roblox.
- 25 verificações das regras de participação, derrota, resgate, saída de jogadores e recompensas.
- Sete cenários de persistência, incluindo falha de leitura, falha de escrita e preservação de ganhos de outro servidor.
- Execução do script de servidor real em um simulador com serviços Roblox substituídos: fila, carregamento antecipado, distância inválida, cancelamento ao mover, reparos, queda, ajuda, carregamento, extração, recompensas e reinício do ciclo.
- XML, referências internas, spawns, objetivos, patrulha, saídas, rig e remoção de scripts importados.

**Ainda não validado:** física real, navegação real do Vigia, aparência renderizada, acesso a cada malha/material externo, carregamento em aparelho real, rede entre clientes e persistência no serviço Roblox. Esses são critérios obrigatórios antes de considerar a versão pronta para lançamento. Não há armas de fogo, PvP, loja, trilha sonora original ou parkour avançado nesta entrega.

## Teste no Studio

1. Teste solo: entre na fila, restaure dois quadros, tente usar o clarão e escape. Verifique se a segunda chance solo funciona uma única vez.
2. Teste com dois clientes: derrube um participante com o perseguidor; ajude, carregue e extraia os dois. Confirme os resultados individuais.
3. Desconecte um jogador caído e outro carregando alguém. O restante da partida precisa continuar.
4. Entre com um terceiro cliente no meio da rodada. Ele deve permanecer no lobby até a próxima.
5. Feche todas as barricadas e observe se o Vigia encontra uma rota ou rompe a passagem. Verifique todos os quadros sorteados nos dois mapas.
6. Use o emulador móvel em paisagem. Confira o pulo padrão, os controles de ação, os prompts e as configurações. Depois faça o teste em um celular real.
7. Publique primeiro em uma experiência de teste. Confira os avisos de assets e DataStore; a capacidade máxima do servidor deve ser configurada na experiência, com alvo de 12 jogadores.

O salvamento usa UpdateAsync para adicionar ganhos. Se a leitura inicial falhar, os ganhos dessa sessão não são gravados, para não sobrescrever um perfil existente. Não há requisito de ativar API no Studio para experimentar a partida; nessa situação, a persistência pode ficar indisponível.

## Reconstruir e editar

`src/` contém os seis scripts separados. A versão `.rbxlx` contém cópias desses scripts. Alterar `src/` não modifica o place até reconstruí-lo.

Para reconstrução, preserve esta estrutura:

```
projeto/
  breu/          # conteúdo desta pasta
  upload/
    Violence_District(3).rbxlx
    1940sHotelLobby - VoidAssets(1).rbxm
  deliverables/
```

Dependências do construtor: Python, numpy e a biblioteca de sistema liblz4. Execute `python breu/tools/build.py` a partir de `projeto/`. Os dois arquivos originais continuam com você e não foram incluídos novamente no pacote. `tools/preview.py` é uma maquete opcional da geometria, sem renderização Roblox.

Testes: `texlua breu/tests/rules_spec.lua`, `texlua breu/tests/profile_spec.lua`, `texlua breu/tests/server_flow_spec.lua` e `python breu/tests/place_spec.py`. Também podem ser executados com outro interpretador Lua 5.3 compatível, ajustando o nome do comando.

## Referências técnicas consultadas

- Roblox, Pathfinding: https://create.roblox.com/docs/characters/pathfinding
- Roblox, client/server security: https://create.roblox.com/docs/scripting/security/client-server-boundary
- Roblox, streaming: https://create.roblox.com/docs/workspace/streaming/techniques
- Roblox, SoundGroup: https://create.roblox.com/docs/reference/engine/classes/SoundGroup

Os scripts foram escritos para o BREU. Os elementos extraídos dos anexos não ganham uma nova licença por serem reutilizados; a disponibilidade deles na experiência depende dos assets correspondentes.
