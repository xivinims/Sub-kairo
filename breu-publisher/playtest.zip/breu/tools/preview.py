"""Illustrative overview from the actual urban map parts; not a Roblox screenshot."""
import xml.etree.ElementTree as E
from pathlib import Path
import numpy as np
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
r=E.parse('deliverables/BREU-Playtest-01.rbxlx').getroot()
m=next(x for x in r.iter('Item') if x.findtext('./Properties/string[@name="Name"]')=='Distrito do Canal')
fig=plt.figure(figsize=(14,10),facecolor='#101a1c');ax=fig.add_subplot(111,projection='3d',facecolor='#101a1c')
faces=[];colors=[]
for x in m.iter('Item'):
 if x.get('class') not in ['Part','TrussPart']:continue
 pr=x.find('Properties');cf=pr.find('CoordinateFrame');sz=pr.find('Vector3[@name="size"]')
 if cf is None or sz is None:continue
 if float(pr.findtext('float[@name="Transparency"]') or 0)>.7:continue
 p=np.array([float(cf.findtext(a)) for a in ['X','Y','Z']]);s=np.array([float(sz.findtext(a)) for a in ['X','Y','Z']])
 if p[1]>16 and x.findtext('./Properties/string[@name="Name"]')=='Cobertura':continue # roof cutaway
 value=int(pr.findtext('Color3uint8') or 4283782485);c=np.array([(value>>16)&255,(value>>8)&255,value&255])/255
 corners=np.array([[a,b,d] for a in [-1,1] for b in [-1,1] for d in [-1,1]])*s/2+p
 corners=corners[:,[0,2,1]]
 for ids,shade in [([0,1,3,2],.65),([4,5,7,6],.82),([0,1,5,4],.72),([2,3,7,6],1.05),([0,2,6,4],.6),([1,3,7,5],.9)]:
  faces.append(corners[ids]);colors.append(np.clip(c*shade,0,1))
ax.add_collection3d(Poly3DCollection(faces,facecolors=colors,edgecolors=(.1,.13,.13,.1),linewidths=.25))
ax.set_xlim(-170,170);ax.set_ylim(-150,150);ax.set_zlim(0,55);ax.set_box_aspect((340,300,110));ax.view_init(elev=48,azim=-64);ax.set_axis_off()
fig.text(.08,.92,'BREU',color='#e4e5d9',fontsize=42,weight='bold')
fig.text(.08,.875,'DISTRITO DO CANAL  /  PLAYTEST 01',color='#a3c8b2',fontsize=13)
fig.text(.08,.06,'Maquete extraída da geometria do arquivo · telhados ocultos para mostrar as rotas\nNão representa iluminação, texturas ou uma captura do Roblox.',color='#9baaa6',fontsize=11)
plt.savefig('deliverables/BREU-Distrito-preview.png',dpi=130,facecolor=fig.get_facecolor(),bbox_inches='tight')
