"""Reproducible BREU place assembly. Never executes supplied scripts."""
from pathlib import Path
import xml.etree.ElementTree as E
import copy,json,math,random,sys
BASE=Path(__file__).resolve().parents[1]
UPLOAD=BASE.parent/'upload'
OUT=BASE.parent/'deliverables'
random.seed(19)
root=E.Element('roblox',{'version':'4'})
counter=0

def item(cls,name,parent):
 global counter
 counter+=1;e=E.SubElement(parent,'Item',{'class':cls,'referent':f'BREU_{counter}'});p=E.SubElement(e,'Properties');prop(e,'string','Name',name);return e

def prop(e,t,n,v):
 p=e.find('Properties')
 for old in list(p):
  if old.get('name')==n:p.remove(old)
 x=E.SubElement(p,t,name=n)
 if isinstance(v,dict):
  for k,z in v.items():E.SubElement(x,k).text=str(z)
 else:x.text=str(v).lower() if isinstance(v,bool) else str(v)
 return x

def vec(e,n,v):prop(e,'Vector3',n,dict(zip(['X','Y','Z'],v)))
def cf(e,v,yaw=0):
 c=math.cos(yaw);s=math.sin(yaw)
 prop(e,'CoordinateFrame','CFrame',dict(zip(['X','Y','Z','R00','R01','R02','R10','R11','R12','R20','R21','R22'],[*v,c,0,s,0,1,0,-s,0,c])))
def color(e,n,c):prop(e,'Color3',n,dict(zip(['R','G','B'],[v/255 for v in c])))
def part(parent,name,pos,size,c=(80,84,82),mat=256,yaw=0,cls='Part',collide=True,trans=0):
 e=item(cls,name,parent);cf(e,pos,yaw);vec(e,'size',size);prop(e,'bool','Anchored',True);prop(e,'bool','CanCollide',collide)
 prop(e,'Color3uint8','Color3uint8',(255<<24)|(c[0]<<16)|(c[1]<<8)|c[2]);prop(e,'token','Material',mat);prop(e,'float','Transparency',trans)
 prop(e,'token','TopSurface',0);prop(e,'token','BottomSurface',0)
 return e

def marker(parent,name,pos):return part(parent,name,pos,(2,.3,2),collide=False,trans=1)
def light(parent,c=(255,207,145),brightness=1.2,ran=18):
 e=item('PointLight','Light',parent);color(e,'Color',c);prop(e,'float','Brightness',brightness);prop(e,'float','Range',ran);prop(e,'bool','Shadows',False);return e

def sign(parent,text,pos,size=(16,3,.2),c=(200,199,173),face=5):
 board=part(parent,'Letreiro',pos,size,(28,35,35),collide=False)
 sg=item('SurfaceGui','Letreiro',board);prop(sg,'token','Face',face);prop(sg,'float','PixelsPerStud',35);prop(sg,'token','SizingMode',1)
 l=item('TextLabel','Texto',sg);prop(l,'string','Text',text);prop(l,'bool','TextScaled',True);prop(l,'bool','TextWrapped',True);prop(l,'float','BackgroundTransparency',1)
 color(l,'TextColor3',c);prop(l,'UDim2','Size',{'XS':1,'XO':0,'YS':1,'YO':0});prop(l,'token','Font',21)
 return board

def mapFolders(model):
 return {n:item('Folder',n,model) for n in ['Spawns','ObjectivePoints','Patrol','Barricades','Supplies','Exits','Pushables']}

def objective(parent,pos):
 e=part(parent,'Quadro',pos,(2.2,3.4,1.3),(166,116,54),1040);light(e,(239,165,75),1.4,15)
 return e

def createUrban(storage):
 m=item('Model','Distrito do Canal',storage);f=mapFolders(m);g=item('Model','Arquitetura',m)
 part(g,'Fundação',(0,-2,0),(340,4,300),(62,65,59),816)
 part(g,'Asfalto',(0,.04,0),(320,.2,30),(39,43,43),1376)
 part(g,'Rua transversal',(0,.07,0),(28,.2,280),(39,43,43),1376)
 for z in [-20,20]:
  part(g,'Calçada',(0,.15,z),(320,.5,8),(108,108,99),816)
  for x in range(-156,157,8):part(g,'Junta do piso',(x,.41,z),(.06,.03,8),(66,72,69),816,collide=False)
 for x in range(-140,141,18):part(g,'Faixa',(x,.17,0),(7,.02,.35),(185,170,119),256,collide=False)
 palette=[(105,74,66),(96,104,94),(139,125,101),(72,88,92),(112,103,96),(91,82,75)]
 locations=[(-106,-67),(-47,-67),(47,-67),(106,-67),(-106,67),(-47,67),(47,67),(106,67)]
 for i,(x,z) in enumerate(locations):
  building=item('Model',['Armazém','Oficina','Pensão','Lavanderia','Mercado','Arquivo','Clínica','Depósito'][i],g)
  wall=palette[i%len(palette)];front=z+(-1 if z>0 else 1)*22
  part(building,'Piso',(x,.4,z),(46,.8,44),(104,99,87),512)
  # Permeable buildings: two doors on opposing sides, side windows and roof route.
  for side in [-1,1]:
   zz=z+side*22
   for offset in [-15,15]:part(building,'Parede de tijolos',(x+offset,8,zz),(16,16,1.2),wall,848)
   part(building,'Verga',(x,13.5,zz),(14,5,1.2),wall,848)
   if side==(1 if z<0 else -1):
    part(f['Barricades'],'Barricada',(x,4,zz),(12,7.5,.7),(111,83,57),512)
  for side in [-1,1]:
   xx=x+side*23
   part(building,'Base da parede',(xx,2.5,z),(1,5,44),wall,848)
   part(building,'Topo da parede',(xx,13,z),(1,6,44),wall,848)
   for oz in [-16,0,16]:part(building,'Coluna',(xx,7.5,z+oz),(1,5,5),wall,848)
   for oz in [-8,8]:
    part(building,'Vidraça',(xx,7.5,z+oz),(.15,4.8,10),(111,141,139),1568,collide=False,trans=.65)
    part(building,'Peitoril',(xx,5,z+oz),(2,.35,10.4),(154,146,126),816)
  part(building,'Cobertura',(x,16.4,z),(48,.8,46),(70,75,72),816)
  for side in [-1,1]:part(building,'Mureta',(x+side*23.5,17.8,z),(1,2,46),wall,848)
  part(building,'Escada externa',(x+20,8,z+25),(2,16,2),(98,108,105),1088,cls='TrussPart')
  sign(building,building.findtext('./Properties/string[@name="Name"]').upper(),(x,11.6,front+(-.7 if z>0 else .7)),(14,2.2,.2),face=2 if z>0 else 5)
  # Furniture islands preserve circulation instead of cluttering all available space.
  for dx,dz in [(-13,-10),(13,9)]:
   part(building,'Bancada',(x+dx,2.8,z+dz),(7,.7,4),(105,82,61),512)
   for a in [-2.5,2.5]:part(building,'Pé',(x+dx+a,1.5,z+dz),( .5,2.5,3),(56,64,62),1088)
  part(building,'Estante',(x-19,4,z),(3,7,10),(89,77,60),512)
  for yy in [1,3.5,6]:part(building,'Prateleira',(x-19,yy,z),(3.4,.3,10.4),(140,112,75),512)
  objective(f['ObjectivePoints'],(x+15,2.7,z-15))
  marker(f['Patrol'],'Rota',(x,3,z));marker(f['Patrol'],'Rota',(x,3,front-10 if z<0 else front+10))
  if i%2==0:part(f['Supplies'],'Curativo',(x-12,3.5,z-10),(1.4,.5,1),(207,213,190),256)
 # Rooftop bridge and alley crates create loops; every barricade has another route.
 for x in [-76,76]:part(g,'Passarela',(x,16.5,-67),(16,.6,6),(81,89,82),512)
 for x in [-145,145]:
  for z in [-115,-40,40,115]:
   part(g,'Poste',(x,7,z),(.4,14,.4),(60,69,66),1088)
   lamp=part(g,'Luminária',(x,14,z),(2,.3,1.5),(220,195,137),288);light(lamp,(242,195,127),1.8,32)
 for x,z in [(-18,-105),(18,105),(-139,0),(139,0),(-8,60),(8,-60)]:
  part(f['Pushables'],'Caixote',(x,1.5,z),(4,3,4),(111,86,60),512)
 # Outer barrier with visible silhouettes; avoid a flat void at the edge of the arena.
 for x,z,sx,sz in [(0,-148,340,2),(0,148,340,2),(-168,0,2,300),(168,0,2,300)]:
  part(g,'Muro do canal',(x,5,z),(sx,10,sz),(67,74,71),816)
 for x in [-150,-105,-60,-15,30,75,120,155]:
  part(g,'Silueta distante',(x,16,-156),(30,32,12),(37,44,45),816)
 for i,(x,z) in enumerate([(-140,-110),(140,110)]):
  e=part(f['Exits'],['Portão oeste','Portão leste'][i],(x,3.5,z),(10,7,8),(135,199,170),288,collide=False,trans=.85)
  l=light(e,(135,221,182),2,36);prop(l,'bool','Enabled',False)
  sign(g,'PONTO DE RESGATE',(x,9,z),(18,2,.2))
 for i in range(12):marker(f['Spawns'],'Entrada',( -12+(i%4)*8,3,117+(i//4)*6))
 marker(m,'HunterSpawn',(0,3,-123))
 return m

def clean(element):
 removed=0
 forbidden={'Script','LocalScript','ModuleScript','ClickDetector','ProximityPrompt','TouchTransmitter','Sound','ParticleEmitter','Fire','Smoke','Humanoid','AnimationController','Animator','RemoteEvent','RemoteFunction','SpawnLocation'}
 for parent in list(element.iter()):
  for child in list(parent):
   if child.tag=='Item' and child.get('class') in forbidden:parent.remove(child);removed+=1
 for e in element.iter('Item'):
  pr=e.find('Properties')
  if pr is None:continue
  for p in list(pr):
   if p.tag in ['Ref','SecurityCapabilities'] or p.get('name') in ['AttributesSerialize','Tags','Capabilities','DefinesCapabilities','HistoryId','UniqueId','SourceAssetId']:
    pr.remove(p)
  if e.get('class') in ['Part','MeshPart','UnionOperation','WedgePart','TrussPart']:
   prop(e,'bool','Anchored',True)
 return removed

def createForest(storage,source):
 w=source.find('Item');original=next(x for x in w.findall('Item') if x.findtext('./Properties/string[@name="Name"]')=='Map')
 m=item('Model','Reserva abandonada',storage);geo=copy.deepcopy(original);m.append(geo);removed=clean(geo);f=mapFolders(m)
 # Supplied spawn positions are authored markers, not guessed points inside trees.
 sp=[];hs=[]
 for x in geo.iter('Item'):
  n=x.findtext('./Properties/string[@name="Name"]');c=x.find('./Properties/CoordinateFrame[@name="CFrame"]')
  if c is not None and n in ['SurvivorSpawn','KillerSpawn']:
   v=tuple(float(c.findtext(a)) for a in ['X','Y','Z'])
   (sp if n=='SurvivorSpawn' else hs).append(v);prop(x,'bool','CanCollide',False);prop(x,'float','Transparency',1)
 # Flat outdoor staging pads make objectives and escape points independent of meshes loading.
 if not sp:raise ValueError('No survivor spawns in supplied geometry')
 for v in sp:marker(f['Spawns'],'Entrada',v);marker(f['Patrol'],'Rota',v)
 marker(m,'HunterSpawn',hs[0] if hs else sp[-1])
 candidates=[sp[0],sp[2],sp[4],sp[6],sp[8]]
 for x,y,z in candidates:
  part(m,'Base do quadro',(x+6,y-1.5,z),(7,1,7),(65,74,69),816)
  objective(f['ObjectivePoints'],(x+6,y+1,z));marker(f['Patrol'],'Rota',(x+6,y,z))
 for i,v in enumerate([sp[0],sp[-1]]):
  x,y,z=v;e=part(f['Exits'],['Estrada da reserva','Torre de vigia'][i],(x,y+1,z),(8,5,8),(135,199,170),288,collide=False,trans=.85);l=light(e);prop(l,'bool','Enabled',False)
 for x,y,z in sp[1::3]:part(f['Supplies'],'Curativo',(x+2,y+.2,z),(1.4,.5,1),(210,214,190))
 return m,removed

def createLobby(workspace,hotel):
 lobby=item('Model','BreuLobby',workspace)
 g=item('Model','Terminal',lobby)
 part(g,'Piso',(1000,198,0),(100,4,80),(74,75,67),512)
 part(g,'Teto',(1000,224,0),(102,2,82),(47,56,54),512)
 for x in [950,1050]:part(g,'Parede',(x,211,0),(2,24,80),(83,88,76),848)
 part(g,'Parede',(1000,211,-40),(100,24,2),(83,88,76),848)
 part(g,'Vidraça',(1000,211,40),(100,24,.3),(102,135,131),1568,trans=.7)
 part(g,'Balcão',(1000,202,-20),(28,4,5),(92,74,58),512)
 sign(g,'BREU  /  TERMINAL 01',(1000,216,-38),(34,4,.2))
 sign(g,'NINGUÉM SAI SOZINHO',(1000,211,-37.8),(28,2,.2))
 for x in [967,1033]:
  for z in [-20,15]:
   pole=part(g,'Luz',(x,220,z),(4,.25,4),(222,199,143),288);light(pole,(244,210,159),2,40)
   part(g,'Banco',(x,201.8,z),(12,1,3),(109,84,61),512)
   for dx in [-4,4]:part(g,'Pé',(x+dx,200.6,z),(1,2,2),(49,59,55),1088)
 # Reuse named static decor only, avoiding the hotel's absent CSG unions and all embedded code.
 borrowed=[]
 for name,target in [('Plant',(975,200,-28)),('SmallPlant',(1025,200,-28)),('Lamp',(1000,204,-20)),('Breifcase',(1007,204,-20))]:
  candidate=next((x for x in hotel.iter('Item') if x.get('class')=='Model' and x.findtext('./Properties/string[@name="Name"]')==name),None)
  if candidate is None:continue
  obj=copy.deepcopy(candidate);clean(obj)
  parts=[x for x in obj.iter('Item') if x.get('class') in ['Part','MeshPart'] and x.find('./Properties/CoordinateFrame[@name="CFrame"]') is not None]
  if not parts:continue
  positions=[[float(x.find('./Properties/CoordinateFrame[@name="CFrame"]').findtext(a)) for a in ['X','Y','Z']] for x in parts]
  center=[sum(v[i] for v in positions)/len(positions) for i in range(3)]
  bottom=min(v[1]-float(x.findtext('./Properties/Vector3[@name="size"]/Y') or '0')/2 for v,x in zip(positions,parts))
  delta=[target[0]-center[0],target[1]-bottom,target[2]-center[2]]
  for part_ in parts:
   c=part_.find('./Properties/CoordinateFrame[@name="CFrame"]')
   for a,d in zip(['X','Y','Z'],delta):c.find(a).text=str(float(c.findtext(a))+d)
  g.append(obj);borrowed.append(name)
 spawn=part(lobby,'Spawn',(1000,200.3,14),(10,.5,8),(90,95,82),cls='SpawnLocation',trans=1,collide=False)
 prop(spawn,'bool','Neutral',True);prop(spawn,'float','Duration',0)
 return borrowed

def hunterRig(storage):
 m=item('Model','BreuHunter',storage);pieces={}
 for name,pos,size,c in [
  ('HumanoidRootPart',(0,4,0),(2,2,1),(25,29,28)),('Torso',(0,4,0),(2,2,1),(40,47,44)),
  ('Head',(0,5.5,0),(1.5,1.5,1.5),(158,154,135)),('Left Arm',(-1.5,4,0),(1,2,1),(40,47,44)),('Right Arm',(1.5,4,0),(1,2,1),(40,47,44)),
  ('Left Leg',(-.5,2,0),(1,2,1),(31,37,36)),('Right Leg',(.5,2,0),(1,2,1),(31,37,36))]:
  p=part(m,name,pos,size,c);prop(p,'bool','Anchored',False);prop(p,'bool','CanCollide',name in ['Torso','Left Leg','Right Leg']);pieces[name]=p
 prop(pieces['HumanoidRootPart'],'float','Transparency',1)
 prop(m,'Ref','PrimaryPart',pieces['HumanoidRootPart'].get('referent'))
 for name,a,b,c0,c1 in [
  ('RootJoint','HumanoidRootPart','Torso',(0,0,0),(0,0,0)),('Neck','Torso','Head',(0,1,0),(0,-.5,0)),
  ('Left Shoulder','Torso','Left Arm',(-1.5,.5,0),(0,.5,0)),('Right Shoulder','Torso','Right Arm',(1.5,.5,0),(0,.5,0)),
  ('Left Hip','Torso','Left Leg',(-.5,-1,0),(0,1,0)),('Right Hip','Torso','Right Leg',(.5,-1,0),(0,1,0))]:
  j=item('Motor6D',name,pieces[a]);prop(j,'Ref','Part0',pieces[a].get('referent'));prop(j,'Ref','Part1',pieces[b].get('referent'))
  for n,v in [('C0',c0),('C1',c1)]:
   prop(j,'CoordinateFrame',n,dict(zip(['X','Y','Z','R00','R01','R02','R10','R11','R12','R20','R21','R22'],[*v,1,0,0,0,1,0,0,0,1])))
 h=item('Humanoid','Humanoid',m);prop(h,'float','MaxHealth',500);prop(h,'float','Health',500);prop(h,'token','DisplayDistanceType',2);prop(h,'bool','RequiresNeck',True)
 item('Animator','Animator',h)
 face=part(m,'Máscara',(0,5.5,-.78),(1.3,1.2,.12),(184,181,163),collide=False);prop(face,'bool','Anchored',False)
 weld=item('WeldConstraint','MaskWeld',face);prop(weld,'Ref','Part0',pieces['Head'].get('referent'));prop(weld,'Ref','Part1',face.get('referent'))
 for dx in [-.3,.3]:
  eye=part(m,'Fenda da máscara',(dx,5.65,-.86),(.22,.16,.08),(20,26,25),collide=False);prop(eye,'bool','Anchored',False)
  joint=item('WeldConstraint','EyeWeld',eye);prop(joint,'Ref','Part0',pieces['Head'].get('referent'));prop(joint,'Ref','Part1',eye.get('referent'))
 return m

def main():
 source=E.parse(UPLOAD/'Violence_District(3).rbxlx').getroot()
 w=item('Workspace','Workspace',root);prop(w,'bool','StreamingEnabled',True);prop(w,'int','StreamingMinRadius',64);prop(w,'int','StreamingTargetRadius',180);prop(w,'float','FallenPartsDestroyHeight',-100)
 players=item('Players','Players',root);prop(players,'int','MaxPlayers',12)
 lighting=item('Lighting','Lighting',root);prop(lighting,'float','ClockTime',19);prop(lighting,'float','Brightness',1.7);prop(lighting,'float','FogStart',25);prop(lighting,'float','FogEnd',600)
 color(lighting,'Ambient',(64,75,76));color(lighting,'OutdoorAmbient',(76,89,92));color(lighting,'FogColor',(37,49,52));prop(lighting,'bool','GlobalShadows',True)
 cc=item('ColorCorrectionEffect','BreuGrade',lighting);prop(cc,'float','Contrast',.12);prop(cc,'float','Saturation',-.18);color(cc,'TintColor',(224,234,226))
 bloom=item('BloomEffect','BreuBloom',lighting);prop(bloom,'float','Intensity',.12);prop(bloom,'float','Size',18);prop(bloom,'float','Threshold',1.8)
 ss=item('ServerStorage','ServerStorage',root);maps=item('Folder','BreuMaps',ss)
 createUrban(maps);forest,removed=createForest(maps,source)
 from hotel_decode import decode
 hotel=decode(UPLOAD/'1940sHotelLobby - VoidAssets(1).rbxm');borrowed=createLobby(w,hotel);hunterRig(ss)
 # Retain original material variants (they contain no scripts); all old gameplay/UI is omitted.
 material=next((x for x in source.findall('Item') if x.get('class')=='MaterialService'),None)
 if material is not None:clean(material);root.append(material)
 rep=item('ReplicatedStorage','ReplicatedStorage',root);shared=item('Folder','Breu',rep)
 for n in ['Action','Feedback']:item('RemoteEvent',n,shared)
 item('Folder','State',shared)
 for name in ['Config','Rules']:
  x=item('ModuleScript',name,shared);prop(x,'ProtectedString','Source',(BASE/'src'/f'{name}.lua').read_text())
 scripts=item('ServerScriptService','ServerScriptService',root)
 for name,cls,file in [('BreuServer','Script','Server.server.lua'),('Hunter','ModuleScript','Hunter.lua'),('Profile','ModuleScript','Profile.lua')]:
  x=item(cls,name,scripts);prop(x,'ProtectedString','Source',(BASE/'src'/file).read_text())
 sp=item('StarterPlayer','StarterPlayer',root);prop(sp,'float','CameraMinZoomDistance',.5);prop(sp,'float','CameraMaxZoomDistance',16)
 sps=item('StarterPlayerScripts','StarterPlayerScripts',sp);x=item('LocalScript','BreuClient',sps);prop(x,'ProtectedString','Source',(BASE/'src/Client.client.lua').read_text())
 item('StarterGui','StarterGui',root);item('SoundService','SoundService',root)
 text=item('TextChatService','TextChatService',root);prop(text,'token','ChatVersion',1)
 # Regenerate referents, including imported ones, preventing collisions between source assets.
 seen=set()
 for e in root.iter('Item'):
  ref=e.get('referent')
  if ref in seen:raise ValueError('Duplicate referent '+ref)
  seen.add(ref)
 OUT.mkdir(exist_ok=True)
 E.ElementTree(root).write(OUT/'BREU-Playtest-01.rbxlx',encoding='utf-8',xml_declaration=True)
 report={'build':'0.1.0-playtest','items':len(list(root.iter('Item'))),'importedMapScriptsRemoved':removed,'hotelDecor':borrowed,'maps':['Distrito do Canal','Reserva abandonada'],'serverScriptsAuthored':3,'externalModelScriptsIncluded':0,'robloxPlaytested':False}
 (BASE/'BUILD_REPORT.json').write_text(json.dumps(report,indent=2,ensure_ascii=False))
 print(json.dumps(report,indent=2,ensure_ascii=False))
if __name__=='__main__':main()
