"""Read the supplied RBXM without running embedded code; extract static geometry."""
import struct,ctypes,ctypes.util,math
from pathlib import Path
import xml.etree.ElementTree as E
import numpy as np

def decode(path):
 b=Path(path).read_bytes();p=32;classes={};props={};parents={};lib=ctypes.CDLL(ctypes.util.find_library('lz4'))
 def ints(d,n,signed=False,delta=False):
  a=np.frombuffer(d[:4*n],dtype=np.uint8).reshape(4,n).astype(np.uint32)
  a=(a[0]<<24)|(a[1]<<16)|(a[2]<<8)|a[3]
  if signed:a=(a>>1).astype(np.int64)^(-(a&1).astype(np.int64))
  if delta:a=np.cumsum(a)
  return a.tolist()
 def floats(d,n):
  a=np.array(ints(d,n),dtype=np.uint32);a=(a>>1)|(a<<31)
  return a.view(np.float32).tolist()
 def strings(d,n):
  out=[];j=0
  for _ in range(n):
   l=struct.unpack_from('<I',d,j)[0];j+=4;out.append(d[j:j+l]);j+=l
  return out
 while p<len(b):
  tag,cs,us,_=struct.unpack_from('<4sIII',b,p);p+=16;d=b[p:p+(cs or us)];p+=cs or us
  if cs:
   o=ctypes.create_string_buffer(us);got=lib.LZ4_decompress_safe(d,o,cs,us)
   if got!=us:raise ValueError('Bad LZ4 chunk')
   d=o.raw
  if tag==b'INST':
   i,l=struct.unpack_from('<II',d);cl=d[8:8+l].decode();n=struct.unpack_from('<I',d,9+l)[0];ids=ints(d[13+l:],n,True,True)
   classes[i]=(cl,n,ids)
   for ref in ids:props[ref]={}
  elif tag==b'PROP':
   i,l=struct.unpack_from('<II',d);name=d[8:8+l].decode();t=d[8+l];d=d[9+l:];cl,n,ids=classes[i];vals=None
   if t==1:vals=strings(d,n)
   elif t==2:vals=[bool(v) for v in d[:n]]
   elif t in [3,11,18,28]:vals=ints(d,n,t==3)
   elif t==4:vals=floats(d,n)
   elif t==5:vals=list(struct.unpack('<'+'d'*n,d))
   elif t in [12,14]:vals=list(zip(*(floats(d[j*4*n:],n) for j in range(3))))
   elif t==26:vals=list(zip(d[:n],d[n:2*n],d[2*n:3*n]))
   elif t==19:vals=ints(d,n,True,True)
   elif t==16:
    mats=[];j=0;axes=np.array([[1,0,0],[0,1,0],[0,0,1],[-1,0,0],[0,-1,0],[0,0,-1]])
    for _ in range(n):
     code=d[j];j+=1
     if code==0:m=struct.unpack_from('<9f',d,j);j+=36
     else:
      x=axes[(code-1)//6];y=axes[(code-1)%6];m=np.column_stack([x,y,np.cross(x,y)]).reshape(-1).tolist()
     mats.append(m)
    xyz=list(zip(*(floats(d[j+k*4*n:],n) for k in range(3))))
    vals=[tuple(xyz[k])+tuple(mats[k]) for k in range(n)]
   if vals is not None:
    for ref,v in zip(ids,vals):props[ref][name]=(t,v)
  elif tag==b'PRNT':
   n=struct.unpack_from('<I',d,1)[0];a=ints(d[5:],n,True,True);v=ints(d[5+4*n:],n,True,True);parents=dict(zip(a,v))
 items={};root=E.Element('Item',{'class':'Model','referent':'HOTEL'});pr=E.SubElement(root,'Properties');E.SubElement(pr,'string',name='Name').text='Hotel1940'
 allowed={'Model','Folder','Part','MeshPart','SpawnLocation','SpecialMesh','Decal','Texture','PointLight','SpotLight','SurfaceLight'}
 content={'MeshId','TextureID','TextureId','Texture'}
 skip={'AttributesSerialize','Tags','Capabilities','DefinesCapabilities','HistoryId','UniqueId','SourceAssetId','PhysicalConfigData','MaterialVariantSerialized','InitialSize','CollisionGroup','CollisionGroupId','CFrame0','CFrame1'}
 for cl,n,refs in classes.values():
  if cl not in allowed:continue
  for ref in refs:
   item=E.Element('Item',{'class': 'Part' if cl=='SpawnLocation' else cl,'referent':'H'+str(ref)});pr=E.SubElement(item,'Properties');items[ref]=item
   for name,(t,v) in props[ref].items():
    if name in skip or t in [19,28] or name.startswith('xml'):continue
    if t==1:
     if name in content:
      e=E.SubElement(pr,'Content',name=name);E.SubElement(e,'url').text=v.decode('utf8','replace')
     elif name=='Name' or name=='MaterialVariant':E.SubElement(pr,'string',name=name).text=v.decode('utf8','replace')
    elif t==2:E.SubElement(pr,'bool',name=name).text=str(v).lower()
    elif t==3:E.SubElement(pr,'int',name=name).text=str(v)
    elif t in [4,5] and math.isfinite(v):E.SubElement(pr,'float',name=name).text=str(v)
    elif t==18:E.SubElement(pr,'token',name=name).text=str(v)
    elif t==26:E.SubElement(pr,'Color3uint8',name=name).text=str((255<<24)|(v[0]<<16)|(v[1]<<8)|v[2])
    elif t in [12,14]:
     e=E.SubElement(pr,'Color3' if t==12 else 'Vector3',name=name)
     for k,z in zip(['R','G','B'] if t==12 else ['X','Y','Z'],v):E.SubElement(e,k).text=str(z)
    elif t==16:
     e=E.SubElement(pr,'CoordinateFrame',name=name)
     for k,z in zip(['X','Y','Z','R00','R01','R02','R10','R11','R12','R20','R21','R22'],v):E.SubElement(e,k).text=str(z)
   if cl in ['Part','MeshPart','SpawnLocation']:
    for e in list(pr):
     if e.get('name')=='Anchored':pr.remove(e)
    E.SubElement(pr,'bool',name='Anchored').text='true'
 for ref,item in items.items():
  parent=parents.get(ref)
  if parent in items:items[parent].append(item)
  else:root.append(item)
 return root
if __name__=='__main__':
 import sys
 r=decode(sys.argv[1]);E.ElementTree(r).write('hotel-decoded.xml')
 print('Extracted',len(list(r.iter('Item'))),'static instances; scripts, unions and effects excluded')
