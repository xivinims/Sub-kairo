local data={u1={coins=40},u2={coins=300}}
local failRead=false
local failWrite=false
local writes=0
local store={}
function store:GetAsync(key) if failRead then error('unavailable') end;return data[key] end
function store:UpdateAsync(key,cb)
 writes=writes+1;if failWrite then error('unavailable') end
 data[key]=cb(data[key]);return data[key]
end
game={GetService=function() return {GetDataStore=function() return store end} end}
warn=function() end
local Profile=dofile('breu/src/Profile.lua')
local api=Profile.start()
local function player(id) return {UserId=id,SetAttribute=function(self,k,v) self[k]=v end} end
local a=player(1);api.load(a);assert(a.Coins==40)
api.award(a,25);api.save(a);assert(data.u1.coins==65)
api.save(a);assert(data.u1.coins==65 and writes==1,'no duplicate saves')
api.award(a,10);failWrite=true;api.save(a);assert(data.u1.coins==65)
failWrite=false;api.save(a);assert(data.u1.coins==75,'failed save retains delta')
-- Another server updates the same account; only session earnings are added.
data.u1.coins=200;api.award(a,15);api.save(a);assert(data.u1.coins==215)
failRead=true;local b=player(2);api.load(b);api.award(b,10);api.save(b)
assert(data.u2.coins==300,'read failure must never overwrite a stored profile')
print('Profile: 7 persistence scenarios passed')
