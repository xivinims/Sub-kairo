-- Deterministic integration harness. Engine services are replaced; the actual server script runs unchanged.
local now=0
local queue={}
local realClock=os.clock
os.clock=function() return now end
math.clamp=function(v,a,b) return math.max(a,math.min(v,b)) end
local function signal()
 local s={listeners={}}
 function s:Connect(fn) table.insert(self.listeners,fn);return {Disconnect=function() end} end
 function s:Fire(...) for _,fn in ipairs(self.listeners) do fn(...) end end
 return s
end
local vecMeta={}
local function vec(x,y,z) return setmetatable({X=x or 0,Y=y or 0,Z=z or 0},vecMeta) end
vecMeta.__add=function(a,b) return vec(a.X+b.X,a.Y+b.Y,a.Z+b.Z) end
vecMeta.__sub=function(a,b) return vec(a.X-b.X,a.Y-b.Y,a.Z-b.Z) end
vecMeta.__mul=function(a,b) if type(a)=='number' then a,b=b,a end;return vec(a.X*b,a.Y*b,a.Z*b) end
vecMeta.__index=function(v,k)
 if k=='Magnitude' then return math.sqrt(v.X*v.X+v.Y*v.Y+v.Z*v.Z) end
 if k=='Unit' then local m=v.Magnitude;return vec(v.X/m,v.Y/m,v.Z/m) end
 if k=='Dot' then return function(a,b) return a.X*b.X+a.Y*b.Y+a.Z*b.Z end end
end
Vector3={new=vec}
local cfMeta={}
local function cf(x,y,z) return setmetatable({Position=vec(x,y,z),LookVector=vec(0,0,-1)},cfMeta) end
cfMeta.__add=function(a,b) local v=a.Position+b;return cf(v.X,v.Y,v.Z) end
cfMeta.__mul=function(a,b) local v=a.Position+b.Position;return cf(v.X,v.Y,v.Z) end
CFrame={new=cf}
Color3={new=function(...) return {...} end,fromRGB=function(...) return {...} end}
Enum=setmetatable({},{__index=function(t,k) local a=setmetatable({},{__index=function(_,v) return v end});rawset(t,k,a);return a end})
RaycastParams={new=function() return {} end}
TweenInfo={new=function() return {} end}
Random={new=function() return {NextNumber=function(_,a,b) return (a+b)/2 end,NextInteger=function(_,a,b) return a end} end}
local methods={}
local objects={}
local function object(class,name,parent)
 local o={ClassName=class,Name=name or class,children={},attributes={},Parent=parent,Enabled=true,Health=100,MaxHealth=100,MoveDirection=vec(),Position=vec(),CFrame=cf(),Size=vec(2,2,2),Triggered=signal(),Died=signal()}
 setmetatable(o,{__index=function(t,k) if methods[k] or t.children[k] then return methods[k] or t.children[k] end;for _,o in ipairs(objects) do if rawget(o,'Parent')==t and rawget(o,'Name')==k then return o end end end})
 if parent then parent.children[o.Name]=o end
 table.insert(objects,o);return o
end
function methods:FindFirstChild(n) return self.children[n] end
function methods:WaitForChild(n) assert(self.children[n],self.Name..'.'..n..' missing');return self.children[n] end
function methods:GetChildren() local a={};for _,c in pairs(self.children) do table.insert(a,c) end;table.sort(a,function(x,y) return x.Name<y.Name end);return a end
function methods:GetDescendants() local a={};for _,c in ipairs(self:GetChildren()) do table.insert(a,c);for _,d in ipairs(c:GetDescendants()) do table.insert(a,d) end end;return a end
function methods:FindFirstChildOfClass(cl) for _,c in ipairs(self:GetChildren()) do if c.ClassName==cl then return c end end end
function methods:IsA(cl) return cl==self.ClassName or cl=='BasePart' and (self.ClassName=='Part' or self.ClassName=='SpawnLocation') end
function methods:IsDescendantOf(a) local p=self.Parent;while p do if p==a then return true end;p=p.Parent end;return false end
function methods:SetAttribute(k,v) self.attributes[k]=v end
function methods:GetAttribute(k) return self.attributes[k] end
function methods:SetNetworkOwner() end
function methods:SetNetworkOwnershipAuto() end
function methods:Destroy() if self.Parent and self.Parent.children[self.Name]==self then self.Parent.children[self.Name]=nil end;self.Parent=nil;self.destroyed=true end
function methods:TakeDamage(d) self.Health=self.Health-d end
function methods:FireClient(p,kind,value) table.insert(self.messages,{p=p,kind=kind,value=value}) end
function methods:FireAllClients(kind,value) table.insert(self.messages,{kind=kind,value=value}) end
function methods:RequestStreamAroundAsync() self.streamRequests=(self.streamRequests or 0)+1 end
function methods:PivotTo(c) if self.PrimaryPart then self.PrimaryPart.CFrame=c;self.PrimaryPart.Position=c.Position end end
Instance={new=function(cl) return object(cl) end}
warn=print
local heartbeat=signal()
task={}
function task.spawn(fn,...) local co=coroutine.create(fn);queue[#queue+1]={co=co,time=now,args={...}} end
function task.delay(seconds,fn) queue[#queue+1]={co=coroutine.create(fn),time=now+seconds,args={}} end
function task.wait(seconds) return coroutine.yield(seconds or .03) end
local function pump(seconds)
 local target=now+seconds
 while now<target do
  now=math.min(target,now+.05)
  local current=queue;queue={}
  for _,entry in ipairs(current) do
   if entry.time<=now then
    local ok,delay=coroutine.resume(entry.co,table.unpack(entry.args));assert(ok,delay)
    if coroutine.status(entry.co)~='dead' then queue[#queue+1]={co=entry.co,time=now+(delay or .03),args={}} end
   else queue[#queue+1]=entry end
  end
  heartbeat:Fire(.05)
 end
end
workspace=object('Workspace','Workspace');function workspace:GetServerTimeNow() return now end
function workspace:Raycast() return nil end
local lobby=object('Model','BreuLobby',workspace);local lobbySpawn=object('Part','Spawn',lobby);lobbySpawn.Position=vec(1000,200,0);lobbySpawn.CFrame=cf(1000,200,0)
local services={Workspace=workspace}
local players=object('Players','Players');services.Players=players;players.PlayerAdded=signal();players.PlayerRemoving=signal();players.list={}
function players:GetPlayers() return self.list end
local rs=object('ReplicatedStorage','ReplicatedStorage');services.ReplicatedStorage=rs
local shared=object('Folder','Breu',rs)
for _,name in ipairs({'Action','Feedback'}) do local n=object('RemoteEvent',name,shared);n.messages={};n.OnServerEvent=signal() end
object('Folder','State',shared)
shared.children.Config={module='Config'};shared.children.Rules={module='Rules'}
local ss=object('ServerStorage','ServerStorage');services.ServerStorage=ss
local maps=object('Folder','BreuMaps',ss);local template=object('Model','HarnessMap',maps)
local function mapClone()
 local m=object('Model','BreuActiveMap',workspace)
 for _,name in ipairs({'Spawns','ObjectivePoints','Patrol','Barricades','Supplies','Exits'}) do object('Folder',name,m) end
 for i=1,3 do
  local s=object('Part','Spawn'..i,m.Spawns);s.Position=vec(i*5,3,0);s.CFrame=cf(i*5,3,0)
  local g=object('Part','Quadro'..i,m.ObjectivePoints);g.Position=vec(i*20,3,0)
 end
 object('Part','Rota',m.Patrol);object('Part','Exit',m.Exits);object('Part','HunterSpawn',m)
 return m
end
function template:Clone() return mapClone() end
local hunterTemplate=object('Model','BreuHunter',ss)
function hunterTemplate:Clone() local m=object('Model','BreuHunter',workspace);m.PrimaryPart=object('Part','HumanoidRootPart',m);return m end
services.Lighting=object('Lighting','Lighting')
services.RunService={Heartbeat=heartbeat}
services.TweenService={Create=function() return {Play=function() end} end}
local records={}
services.DataStoreService={GetDataStore=function() return {GetAsync=function() return nil end,UpdateAsync=function(_,key,cb) records[key]=cb(records[key]) end} end}
game={GetService=function(_,n) assert(services[n],n);return services[n] end,BindToClose=function() end}
local context
local realRequire=require
require=function(m)
 if m.module=='Config' then return dofile('breu/src/Config.lua') end
 if m.module=='Rules' then return dofile('breu/src/Rules.lua') end
 if m.module=='Profile' then return dofile('breu/src/Profile.lua') end
 if m.module=='Hunter' then return {start=function(_,c) context=c;return {stop=function() end,stun=function() end} end} end
 return realRequire(m)
end
script={Parent={Hunter={module='Hunter'},Profile={module='Profile'}}}
dofile('breu/src/Server.server.lua')
local function addPlayer(id)
 local p=object('Player','P'..id);p.UserId=id;p.DisplayName='P'..id;p.CharacterAdded=signal();p.Parent=players
 p.Character=object('Model','Character'..id,workspace);object('Humanoid','Humanoid',p.Character);object('Part','HumanoidRootPart',p.Character)
 table.insert(players.list,p);players.PlayerAdded:Fire(p);return p
end
local a,b=addPlayer(1),addPlayer(2)
local net=shared.Action
net.OnServerEvent:Fire(a,'Ready',true);net.OnServerEvent:Fire(b,'Ready',true)
pump(33)
assert(shared.State:GetAttribute('Phase')=='Round','round did not start')
assert(a:GetAttribute('BreuState')=='Active' and b:GetAttribute('BreuState')=='Active')
assert(context,'hunter was not started')
assert(a.streamRequests>0,'server streaming was not requested')
local map=workspace.BreuActiveMap
local function move(p,part)
 local root=p.Character.HumanoidRootPart;root.Position=part.Position;root.CFrame=cf(root.Position.X,root.Position.Y,root.Position.Z)
end
local function trigger(part,p)
 local prompt
 for _,o in ipairs(objects) do if o.ClassName=='ProximityPrompt' and o.Parent==part then prompt=o end end
 assert(prompt,'missing prompt');prompt.Triggered:Fire(p)
end
local g1,g2,g3=table.unpack(map.ObjectivePoints:GetChildren())
trigger(g1,a);pump(8);assert(shared.State:GetAttribute('Repaired')==0,'remote repair from far away accepted')
move(a,g1);trigger(g1,a);pump(2);a.Character.Humanoid.MoveDirection=vec(1,0,0);pump(.1);a.Character.Humanoid.MoveDirection=vec();pump(6)
assert(shared.State:GetAttribute('Repaired')==0,'moving did not cancel repair')
move(a,g1);trigger(g1,a);move(b,g2);trigger(g2,b);pump(7.3)
assert(shared.State:GetAttribute('Repaired')==2,'repairs failed')
context.damage(a,200);assert(a:GetAttribute('BreuState')=='Downed')
move(b,a.Character.HumanoidRootPart);net.OnServerEvent:Fire(b,'Revive');pump(4.3)
assert(a:GetAttribute('BreuState')=='Active' and a.Character.Humanoid.Health==55,'revive failed')
move(a,g3);trigger(g3,a);pump(7.6)
assert(shared.State:GetAttribute('Phase')=='Extraction','power did not open extraction')
context.damage(a,200);move(b,a.Character.HumanoidRootPart);net.OnServerEvent:Fire(b,'Carry');pump(.2)
assert(b:GetAttribute('Carrying')==true and a:GetAttribute('CarriedBy')==b.UserId,'carry failed')
local exit=map.Exits:GetChildren()[1];move(b,exit);move(a,exit);trigger(exit,b);pump(2.2)
local resultA,resultB
for _,m in ipairs(shared.Feedback.messages) do if m.kind=='Results' then if m.p==a then resultA=m.value elseif m.p==b then resultB=m.value end end end
assert(resultA and resultB,'no round results')
assert(resultA.escaped and resultB.escaped,'carried survivor did not escape')
assert(resultA.coins==140 and resultB.coins==145,'support rewards wrong')
pump(13)
assert(shared.State:GetAttribute('Phase')=='Intermission','round did not return to lobby cycle')
print('Server integration: queue, streaming, distance rejection, repair cancellation, repairs, down, revive, carry, extraction, rewards and next-round cycle passed')
os.clock=realClock
