local Rules=dofile('breu/src/Rules.lua')
local Config=dofile('breu/src/Config.lua')
local tests=0
local function equal(a,b,message)
 tests=tests+1
 assert(a==b,(message or '')..' expected '..tostring(b)..', got '..tostring(a))
end
equal(Rules.canAct('Active'),true,'active can interact')
for _,s in ipairs({'Downed','Escaped','Eliminated','Lobby'}) do equal(Rules.canAct(s),false,s..' denied') end
equal(Rules.canRevive('Active','Downed'),true)
equal(Rules.canRevive('Downed','Downed'),false)
equal(Rules.canRevive('Active','Active'),false)
equal(Rules.result({a='Active',b='Downed'},1),nil,'keep running while a rescuer exists')
equal(Rules.result({a='Downed',b='Eliminated'},99),'Ninguém voltou','no rescuers left')
equal(Rules.result({a='Escaped',b='Downed'},99),'Resgate concluído','one rescue is still a success')
equal(Rules.result({a='Active'},0),'O resgate partiu','timeout')
equal(Rules.result({a='Lobby',b='Escaped'},99),'Resgate concluído','late arrivals excluded')
equal(Rules.result({},99),'Ninguém voltou','all disconnected')
equal(Rules.requiredGenerators(1,5),2,'solo balance')
equal(Rules.requiredGenerators(12,5),3,'co-op balance')
equal(Rules.requiredGenerators(12,2),2,'never request more than available')
equal(Rules.reward(true,2,1,Config),165,'escape and support reward')
equal(Rules.reward(false,1,2,Config),70,'support rewarded on defeat')
-- Full state progression: repair stage, down, revive, disconnect, escape, finish.
local states={a='Active',b='Active',c='Active'}
equal(Rules.result(states,100),nil)
states.a='Downed';equal(Rules.result(states,90),nil)
equal(Rules.canRevive(states.b,states.a),true);states.a='Active'
states.c=nil;equal(Rules.result(states,80),nil)
states.a='Escaped';equal(Rules.result(states,20),nil)
states.b='Escaped';equal(Rules.result(states,15),'Resgate concluído')
print('Rules: '..tests..' assertions passed')
