from pathlib import Path
import xml.etree.ElementTree as E
from collections import Counter
p=Path('deliverables/BREU-Playtest-01.rbxlx');r=E.parse(p).getroot()
def name(e):return e.findtext('./Properties/string[@name="Name"]')
def child(parent,n):return next(x for x in parent.findall('Item') if name(x)==n)
refs={e.get('referent') for e in r.iter('Item')}
assert len(refs)==len(list(r.iter('Item')))
for e in r.iter('Ref'):assert e.text in refs or e.text in ['null','nil',None],e.text
scripts=[e for e in r.iter('Item') if e.get('class') in ['Script','LocalScript','ModuleScript']]
assert len(scripts)==6,len(scripts)
for x in scripts:
 source=x.findtext('./Properties/ProtectedString[@name="Source"]')
 assert source and 'Decompiled with' not in source and 'loadstring' not in source
 assert 'require(' not in source or 'require(script.' in source or 'require(Shared.' in source or 'require(shared.' in source
ss=child(r,'ServerStorage');maps=child(ss,'BreuMaps')
for m in maps.findall('Item'):
 spawns=child(m,'Spawns').findall('Item');assert len(spawns)>=8
 assert len(child(m,'ObjectivePoints').findall('Item'))>=3
 assert len(child(m,'Patrol').findall('Item'))>=2
 assert len(child(m,'Exits').findall('Item'))==2
 child(m,'HunterSpawn')
 for x in m.iter('Item'):
  if x.get('class') in ['Part','MeshPart','UnionOperation','TrussPart']:
   assert x.findtext('./Properties/bool[@name="Anchored"]')=='true'
  assert x.get('class') not in ['Script','LocalScript','ModuleScript','RemoteEvent','RemoteFunction','SpawnLocation']
 print(name(m),':',len(spawns),'spawns,',len(list(m.iter('Item'))),'instances')
w=child(r,'Workspace');lobby=child(w,'BreuLobby');spawn=child(lobby,'Spawn')
assert spawn.get('class')=='SpawnLocation'
assert w.findtext('./Properties/bool[@name="StreamingEnabled"]')=='true'
assert len([x for x in r.iter('Item') if x.get('class')=='SpawnLocation'])==1
rig=child(ss,'BreuHunter');assert len([x for x in rig.iter('Item') if x.get('class')=='Motor6D'])==6
print('Place: valid XML, six authored scripts, valid refs, static imported assets, both maps have required gameplay markers')
