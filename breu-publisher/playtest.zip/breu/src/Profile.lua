local DataStoreService=game:GetService('DataStoreService')
local Profile={}
function Profile.start()
 local store=DataStoreService:GetDataStore('BREU_Profile_v1')
 local profiles={}
 local api={}
 function api.load(p)
  local ok,data=pcall(function() return store:GetAsync('u'..p.UserId) end)
  if not ok then warn('BREU: perfil indisponível; sessão não será salva para evitar sobrescrita.') end
  profiles[p]={coins=ok and type(data)=='table' and tonumber(data.coins) or 0, earned=0, loaded=ok, saving=false}
  p:SetAttribute('Coins',profiles[p].coins)
 end
 function api.award(p,amount)
  local d=profiles[p];if not d then return end
  d.coins=d.coins+amount;d.earned=d.earned+amount;p:SetAttribute('Coins',d.coins)
 end
 function api.save(p)
  local d=profiles[p];if not d or not d.loaded or d.saving or d.earned==0 then return end
  d.saving=true
  local delta=d.earned
  local ok=pcall(function()
   store:UpdateAsync('u'..p.UserId,function(old)
    old=type(old)=='table' and old or {}
    return {coins=(tonumber(old.coins) or 0)+delta}
   end)
  end)
  if ok then d.earned=d.earned-delta end
  d.saving=false
 end
 function api.remove(p) api.save(p);profiles[p]=nil end
 return api
end
return Profile
