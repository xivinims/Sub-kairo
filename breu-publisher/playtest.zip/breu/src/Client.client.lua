local Players=game:GetService('Players')
local RS=game:GetService('ReplicatedStorage')
local UIS=game:GetService('UserInputService')
local CAS=game:GetService('ContextActionService')
local Run=game:GetService('RunService')
local Tween=game:GetService('TweenService')
local Lighting=game:GetService('Lighting')
local SoundService=game:GetService('SoundService')
local StarterGui=game:GetService('StarterGui')
local p=Players.LocalPlayer
local shared=RS:WaitForChild('Breu')
local state=shared:WaitForChild('State')
local action=shared:WaitForChild('Action')
local feed=shared:WaitForChild('Feedback')
local config=require(shared.Config)
local camera=workspace.CurrentCamera
local C={ink=Color3.fromRGB(15,20,22),panel=Color3.fromRGB(26,33,35),paper=Color3.fromRGB(232,230,218),muted=Color3.fromRGB(158,173,169),accent=Color3.fromRGB(158,198,173),danger=Color3.fromRGB(226,133,108)}
local gui=Instance.new('ScreenGui');gui.Name='BreuInterface';gui.ResetOnSpawn=false;gui.IgnoreGuiInset=false;gui.ZIndexBehavior=Enum.ZIndexBehavior.Sibling;gui.Parent=p:WaitForChild('PlayerGui')
pcall(function() StarterGui:SetCoreGuiEnabled(Enum.CoreGuiType.Health,false) end)
local function create(class,parent,props)
 local x=Instance.new(class);for k,v in pairs(props or {}) do x[k]=v end;x.Parent=parent;return x
end
local function round(x,r) create('UICorner',x,{CornerRadius=UDim.new(0,r or 10)}) end
local function stroke(x,color) create('UIStroke',x,{Color=color or C.muted,Transparency=.75,Thickness=1}) end
local function frame(parent,size,pos,color)
 return create('Frame',parent,{Size=size,Position=pos or UDim2.new(),BackgroundColor3=color or C.panel,BorderSizePixel=0})
end
local function label(parent,text,size,pos,fontSize,color)
 return create('TextLabel',parent,{Text=text,Size=size,Position=pos or UDim2.new(),BackgroundTransparency=1,TextColor3=color or C.paper,Font=Enum.Font.Gotham,TextSize=fontSize or 14,TextXAlignment=Enum.TextXAlignment.Left,TextWrapped=true})
end
local function button(parent,text,size,pos,callback)
 local b=create('TextButton',parent,{Text=text,Size=size,Position=pos,BackgroundColor3=C.panel,TextColor3=C.paper,TextSize=14,Font=Enum.Font.GothamMedium,AutoButtonColor=true,BorderSizePixel=0})
 round(b,8);stroke(b);b.Activated:Connect(callback);return b
end
local root=frame(gui,UDim2.fromScale(1,1),nil,C.ink);root.BackgroundTransparency=1
local layoutScale=create('UIScale',root,{Scale=1})
local header=frame(root,UDim2.fromOffset(370,74),UDim2.new(.5,-185,0,8));round(header);stroke(header)
local phaseLabel=label(header,'AGUARDANDO',UDim2.new(1,-85,0,20),UDim2.fromOffset(16,9),12,C.accent)
phaseLabel.Font=Enum.Font.GothamBold
local timer=label(header,'—',UDim2.fromOffset(65,30),UDim2.new(1,-78,0,12),25);timer.TextXAlignment=Enum.TextXAlignment.Right
local objective=label(header,'Entre na fila para a próxima rodada.',UDim2.new(1,-30,0,28),UDim2.fromOffset(16,33),13)
local coin=label(root,'',UDim2.fromOffset(130,30),UDim2.new(1,-178,0,18),13,C.accent);coin.TextXAlignment=Enum.TextXAlignment.Right
local vitals=frame(root,UDim2.fromOffset(210,69),UDim2.new(0,20,1,-91));round(vitals);stroke(vitals)
local healthText=label(vitals,'SAÚDE',UDim2.fromOffset(180,16),UDim2.fromOffset(13,8),10)
local healthTrack=frame(vitals,UDim2.new(1,-26,0,5),UDim2.fromOffset(13,29),C.ink);round(healthTrack,3)
local healthFill=frame(healthTrack,UDim2.fromScale(1,1),nil,C.accent);round(healthFill,3)
local staminaTrack=frame(vitals,UDim2.new(1,-26,0,3),UDim2.fromOffset(13,47),C.ink)
local staminaFill=frame(staminaTrack,UDim2.fromScale(1,1),nil,C.paper)
local notice=label(root,'',UDim2.new(.8,0,0,42),UDim2.new(.1,0,.2,0),16);notice.TextXAlignment=Enum.TextXAlignment.Center;notice.TextStrokeTransparency=.45
local progress=frame(root,UDim2.fromOffset(280,64),UDim2.new(.5,-140,.7,0));round(progress);stroke(progress);progress.Visible=false
button(progress,'×',UDim2.fromOffset(26,26),UDim2.new(1,-33,0,6),function() action:FireServer('Cancel') end)
local progressText=label(progress,'',UDim2.new(1,-55,0,25),UDim2.fromOffset(12,6),13)
local progressTrack=frame(progress,UDim2.new(1,-24,0,5),UDim2.fromOffset(12,38),C.ink)
local progressFill=frame(progressTrack,UDim2.fromScale(0,1),nil,C.accent)
local progressAt,progressDuration=0,0
local menu=frame(root,UDim2.fromScale(1,1),nil,C.ink);menu.BackgroundTransparency=.12
local menuContent=frame(menu,UDim2.fromOffset(420,390),UDim2.new(.09,0,.5,-195));menuContent.BackgroundTransparency=1
label(menuContent,'AURIVANE WORKS',UDim2.fromOffset(340,24),UDim2.new(),12,C.accent)
local title=label(menuContent,'BREU',UDim2.fromOffset(390,95),UDim2.fromOffset(-4,25),85);title.Font=Enum.Font.GothamBlack
label(menuContent,'NINGUÉM SAI SOZINHO.',UDim2.fromOffset(390,25),UDim2.fromOffset(1,124),14,C.muted)
label(menuContent,'Restaure a energia. Improvise caminhos.\nBusque quem ficou para trás.',UDim2.fromOffset(390,60),UDim2.fromOffset(1,166),17)
local playButton=button(menuContent,'ENTRAR NA PRÓXIMA RODADA  →',UDim2.fromOffset(340,49),UDim2.fromOffset(0,251),function()
 action:FireServer('Ready',true);menu.Visible=false
end);playButton.BackgroundColor3=C.accent;playButton.TextColor3=C.ink
button(menuContent,'EXPLORAR O LOBBY',UDim2.fromOffset(340,42),UDim2.fromOffset(0,310),function() menu.Visible=false end)
label(menu,'PLAYTEST 01  /  SOBREVIVÊNCIA COOPERATIVA',UDim2.fromOffset(400,22),UDim2.new(0,28,1,-34),10,C.muted)
local settings=frame(root,UDim2.fromOffset(326,356),UDim2.new(1,-342,.5,-178));round(settings);stroke(settings);settings.Visible=false
label(settings,'AJUSTES',UDim2.fromOffset(220,32),UDim2.fromOffset(22,15),19)
button(settings,'×',UDim2.fromOffset(32,32),UDim2.new(1,-47,0,15),function() settings.Visible=false end)
local lowEffects=UIS.TouchEnabled
local shadows=not lowEffects
local fov=76
local audio=true
local master=create('SoundGroup',SoundService,{Name='BreuMaster',Volume=.65})
local function routeSound(x) if x:IsA('Sound') then x.SoundGroup=master end end
for _,x in ipairs(game:GetDescendants()) do routeSound(x) end
game.DescendantAdded:Connect(routeSound)
local function applyEffects()
 Lighting.GlobalShadows=shadows
 for _,x in ipairs(Lighting:GetChildren()) do
  if x:IsA('PostEffect') then x.Enabled=not lowEffects end
 end
end
local effectsButton,shadowButton,soundButton
local function refreshSettings()
 effectsButton.Text='EFEITOS  ·  '..(lowEffects and 'REDUZIDOS' or 'COMPLETOS')
 shadowButton.Text='SOMBRAS  ·  '..(shadows and 'LIGADAS' or 'DESLIGADAS')
 soundButton.Text='ÁUDIO  ·  '..(audio and 'LIGADO' or 'MUDO')
 applyEffects()
end
effectsButton=button(settings,'',UDim2.fromOffset(282,40),UDim2.fromOffset(22,68),function() lowEffects=not lowEffects;refreshSettings() end)
shadowButton=button(settings,'',UDim2.fromOffset(282,40),UDim2.fromOffset(22,120),function() shadows=not shadows;refreshSettings() end)
soundButton=button(settings,'',UDim2.fromOffset(282,40),UDim2.fromOffset(22,172),function() audio=not audio;master.Volume=audio and .65 or 0;refreshSettings() end)
local fovLabel=label(settings,'CAMPO DE VISÃO  ·  76',UDim2.fromOffset(210,28),UDim2.fromOffset(22,228),12)
button(settings,'−',UDim2.fromOffset(42,34),UDim2.fromOffset(206,262),function() fov=math.max(65,fov-5);fovLabel.Text='CAMPO DE VISÃO  ·  '..fov end)
button(settings,'+',UDim2.fromOffset(42,34),UDim2.fromOffset(260,262),function() fov=math.min(95,fov+5);fovLabel.Text='CAMPO DE VISÃO  ·  '..fov end)
label(settings,'No celular, efeitos reduzidos vêm ativados.',UDim2.fromOffset(282,27),UDim2.fromOffset(22,312),11,C.muted)
refreshSettings()
button(root,'⚙',UDim2.fromOffset(38,38),UDim2.new(1,-48,0,12),function() settings.Visible=not settings.Visible end)
local menuButton=button(root,'≡',UDim2.fromOffset(38,38),UDim2.fromOffset(12,12),function() menu.Visible=not menu.Visible end)
local readyButton
readyButton=button(root,'ENTRAR NA FILA',UDim2.fromOffset(190,38),UDim2.new(.5,-95,1,-65),function()
 action:FireServer('Ready',not p:GetAttribute('Ready'))
end)
local actions=frame(root,UDim2.fromOffset(242,174),UDim2.new(1,-330,1,-240));actions.BackgroundTransparency=1
local sprintButton=button(actions,'⇧',UDim2.fromOffset(64,64),UDim2.fromOffset(170,100),function() action:FireServer('Sprint',not p:GetAttribute('Sprinting')) end);round(sprintButton,32)
local crouchButton=button(actions,'↓',UDim2.fromOffset(52,52),UDim2.fromOffset(104,111),function() action:FireServer('Crouch',not p:GetAttribute('Crouching')) end);round(crouchButton,26)
local flashButton=button(actions,'✦',UDim2.fromOffset(52,52),UDim2.fromOffset(174,35),function() action:FireServer('Flash') end);round(flashButton,26)
local reviveButton=button(actions,'+',UDim2.fromOffset(52,52),UDim2.fromOffset(41,81),function() action:FireServer('Revive') end);round(reviveButton,26)
local carryButton=button(actions,'↥',UDim2.fromOffset(52,52),UDim2.fromOffset(100,34),function() action:FireServer('Carry') end);round(carryButton,26)
local hints=label(root,'SHIFT correr  ·  C agachar  ·  F clarão  ·  R ajudar  ·  G carregar  ·  E interagir',UDim2.fromOffset(600,24),UDim2.new(.5,-300,1,-30),11,C.muted);hints.TextXAlignment=Enum.TextXAlignment.Center
local spectator=frame(root,UDim2.fromOffset(300,76),UDim2.new(.5,-150,1,-126));round(spectator);stroke(spectator);spectator.Visible=false
local spectateLabel=label(spectator,'ASSISTINDO',UDim2.fromOffset(200,44),UDim2.fromOffset(50,5),13);spectateLabel.TextXAlignment=Enum.TextXAlignment.Center
local spectateIndex=1
button(spectator,'‹',UDim2.fromOffset(36,36),UDim2.fromOffset(8,17),function() spectateIndex=spectateIndex-1 end)
button(spectator,'›',UDim2.fromOffset(36,36),UDim2.new(1,-44,0,17),function() spectateIndex=spectateIndex+1 end)
local resultPanel=frame(root,UDim2.fromOffset(370,266),UDim2.new(.5,-185,.5,-133));round(resultPanel);stroke(resultPanel);resultPanel.Visible=false
local resultTitle=label(resultPanel,'',UDim2.fromOffset(324,50),UDim2.fromOffset(23,24),23)
local resultBody=label(resultPanel,'',UDim2.fromOffset(324,102),UDim2.fromOffset(23,85),15,C.muted)
button(resultPanel,'CONTINUAR',UDim2.fromOffset(324,40),UDim2.fromOffset(23,205),function() resultPanel.Visible=false end)
local hitOverlay=frame(gui,UDim2.fromScale(1,1),nil,C.danger);hitOverlay.BackgroundTransparency=1;hitOverlay.ZIndex=30
local intro=frame(gui,UDim2.fromScale(1,1),nil,C.ink);intro.ZIndex=50
local introLabel=label(intro,'AURIVANE WORKS',UDim2.fromScale(1,.1),UDim2.fromScale(0,.45),20);introLabel.TextXAlignment=Enum.TextXAlignment.Center;introLabel.ZIndex=51
local transition=frame(gui,UDim2.fromScale(1,1),nil,C.ink);transition.ZIndex=40;transition.Visible=false
local transitionText=label(transition,'ENTRANDO NA INCURSÃO…',UDim2.fromScale(1,.1),UDim2.fromScale(0,.45),17,C.accent);transitionText.TextXAlignment=Enum.TextXAlignment.Center;transitionText.ZIndex=41
local noticeId=0
local function showNotice(text)
 noticeId=noticeId+1;local id=noticeId;notice.Text=text
 task.delay(5,function() if noticeId==id then notice.Text='' end end)
end
feed.OnClientEvent:Connect(function(kind,value)
 if kind=='Transition' then
  transition.Visible=true;transition.BackgroundTransparency=0
 elseif kind=='TransitionDone' then
  Tween:Create(transition,TweenInfo.new(.5),{BackgroundTransparency=1}):Play()
  task.delay(.5,function() transition.Visible=false end)
 elseif kind=='Notice' then showNotice(value)
 elseif kind=='Progress' then
  progress.Visible=value~=false
  if value then progressText.Text=value.text;progressAt=os.clock();progressDuration=value.duration end
 elseif kind=='Hit' then
  hitOverlay.BackgroundColor3=C.danger;hitOverlay.BackgroundTransparency=.65
  Tween:Create(hitOverlay,TweenInfo.new(.65),{BackgroundTransparency=1}):Play()
 elseif kind=='Flash' then
  hitOverlay.BackgroundColor3=C.paper;hitOverlay.BackgroundTransparency=.1
  Tween:Create(hitOverlay,TweenInfo.new(.35),{BackgroundTransparency=1}):Play()
 elseif kind=='Results' then
  resultTitle.Text=value.title
  resultBody.Text=(value.escaped and 'VOCÊ CONSEGUIU SAIR' or 'VOCÊ FICOU PARA TRÁS')..'\n\n+'..value.coins..' fichas  ·  '..value.repairs..' reparos\n'..value.revives..' companheiros ajudados'
  resultPanel.Visible=true
 end
end)
local function bind(name,key,callback)
 CAS:BindAction(name,function(_,input)
  if UIS:GetFocusedTextBox() then return Enum.ContextActionResult.Pass end
  callback(input);return Enum.ContextActionResult.Sink
 end,false,key)
end
bind('BreuSprint',Enum.KeyCode.LeftShift,function(input) if input==Enum.UserInputState.Begin then action:FireServer('Sprint',true) elseif input==Enum.UserInputState.End or input==Enum.UserInputState.Cancel then action:FireServer('Sprint',false) end end)
bind('BreuCrouch',Enum.KeyCode.C,function(input) if input==Enum.UserInputState.Begin then action:FireServer('Crouch',not p:GetAttribute('Crouching')) end end)
bind('BreuFlash',Enum.KeyCode.F,function(input) if input==Enum.UserInputState.Begin then action:FireServer('Flash') end end)
bind('BreuRevive',Enum.KeyCode.R,function(input) if input==Enum.UserInputState.Begin then action:FireServer('Revive') end end)
bind('BreuCarry',Enum.KeyCode.G,function(input) if input==Enum.UserInputState.Begin then action:FireServer('Carry') end end)
bind('BreuSettings',Enum.KeyCode.M,function(input) if input==Enum.UserInputState.Begin then settings.Visible=not settings.Visible end end)
bind('BreuCancel',Enum.KeyCode.Backspace,function(input) if input==Enum.UserInputState.Begin then action:FireServer('Cancel') end end)
-- Gamepad uses the same server actions; X is reserved for world prompts.
for _,entry in ipairs({{'Sprint',Enum.KeyCode.ButtonL3},{'Crouch',Enum.KeyCode.ButtonB},{'Flash',Enum.KeyCode.ButtonY},{'Revive',Enum.KeyCode.DPadUp},{'Carry',Enum.KeyCode.DPadDown}}) do
 bind('BreuPad'..entry[1],entry[2],function(input)
  if input==Enum.UserInputState.Begin then
   if entry[1]=='Sprint' then action:FireServer('Sprint',not p:GetAttribute('Sprinting'))
   elseif entry[1]=='Crouch' then action:FireServer('Crouch',not p:GetAttribute('Crouching'))
   else action:FireServer(entry[1]) end
  end
 end)
end
local phaseNames={Lobby='AGUARDANDO',Intermission='PRÓXIMA INCURSÃO',Preparing='PREPARANDO INCURSÃO',Round='RESTAURE A ENERGIA',Extraction='CORRA ATÉ O RESGATE',Results='FIM DA INCURSÃO'}
local lastState=''
local lastHealth=100
Run.RenderStepped:Connect(function(dt)
 camera=workspace.CurrentCamera
 local viewport=camera.ViewportSize
 local small=viewport.X<750
 header.Size=UDim2.fromOffset(small and 290 or 370,74);header.Position=UDim2.new(.5,small and -145 or -185,0,8)
 menuContent.Position=small and UDim2.new(.06,0,.5,-175) or UDim2.new(.09,0,.5,-195)
 local ms=menuContent:FindFirstChildOfClass('UIScale') or create('UIScale',menuContent,{Scale=1});ms.Scale=small and .78 or 1
 coin.Visible=viewport.X>700
 settings.Size=UDim2.fromOffset(326,356)
 local ss=settings:FindFirstChildOfClass('UIScale') or create('UIScale',settings,{Scale=1});ss.Scale=math.min(1,(viewport.Y-30)/356)
 settings.Position=UDim2.new(1,-(326*ss.Scale)-14,.5,-178*ss.Scale)
 local status=p:GetAttribute('BreuState') or 'Lobby'
 local phase=state:GetAttribute('Phase') or 'Lobby'
 local playing=status=='Active' or status=='Downed'
 if status~=lastState then
  if playing then menu.Visible=false;resultPanel.Visible=false end
  lastState=status
 end
 actions.Visible=playing and status=='Active' and UIS.TouchEnabled and not menu.Visible and not settings.Visible
 hints.Visible=playing
 hints.Text=UIS.TouchEnabled and '⇧ correr  ·  ↓ agachar  ·  ✦ clarão  ·  + ajudar  ·  ↥ carregar' or 'SHIFT correr  ·  C agachar  ·  F clarão  ·  R ajudar  ·  G carregar  ·  E interagir'
 hints.Size=UDim2.fromOffset(math.min(600,viewport.X-40),24);hints.Position=UDim2.new(.5,-math.min(600,viewport.X-40)/2,1,-28)
 vitals.Position=UIS.TouchEnabled and UDim2.fromOffset(12,98) or UDim2.new(0,20,1,-91)
 vitals.Size=UDim2.fromOffset(UIS.TouchEnabled and 165 or 210,69)
 vitals.Visible=playing and not menu.Visible
 readyButton.Visible=not playing and not menu.Visible and phase~='Results'
 readyButton.Text=p:GetAttribute('Ready') and 'NA FILA  ·  SAIR' or 'ENTRAR NA FILA'
 phaseLabel.Text=phaseNames[phase] or phase
 local seconds=math.max(0,math.ceil((state:GetAttribute('EndsAt') or workspace:GetServerTimeNow())-workspace:GetServerTimeNow()))
 timer.Text=string.format('%02d:%02d',math.floor(seconds/60),seconds%60)
 if phase=='Round' then objective.Text=(state:GetAttribute('Map') or '')..'  ·  '..(state:GetAttribute('Repaired') or 0)..'/'..(state:GetAttribute('Required') or 3)..' quadros'
 elseif phase=='Extraction' then objective.Text='RESGATE: '..(state:GetAttribute('Exit') or '')
 elseif phase=='Preparing' then objective.Text='Preparando o cenário e os sobreviventes.'
 elseif phase=='Intermission' then objective.Text=p:GetAttribute('Ready') and 'Você está na fila. Prepare-se.' or 'Entre na fila para participar.'
 else objective.Text=phase=='Results' and (state:GetAttribute('Result') or '') or 'Explore o lobby e entre na fila.' end
 coin.Text='◉  '..(p:GetAttribute('Coins') or 0)
 local c=p.Character;local h=c and c:FindFirstChildOfClass('Humanoid')
 if h then
  healthFill.Size=UDim2.fromScale(math.clamp(h.Health/h.MaxHealth,0,1),1)
  healthText.Text=status=='Downed' and ('CAÍDO  ·  '..(p:GetAttribute('Bleedout') or 0)..'s') or ('SAÚDE  '..math.ceil(h.Health))
 end
 staminaFill.Size=UDim2.fromScale((p:GetAttribute('Stamina') or 100)/100,1)
 local cd=math.max(0,math.ceil((p:GetAttribute('FlashReadyAt') or 0)-workspace:GetServerTimeNow()))
 flashButton.Text=cd>0 and tostring(cd) or '✦'
 sprintButton.BackgroundColor3=p:GetAttribute('Sprinting') and C.accent or C.panel
 carryButton.Text=p:GetAttribute('Carrying') and '↓' or '↥'
 if progress.Visible then progressFill.Size=UDim2.fromScale(math.clamp((os.clock()-progressAt)/math.max(.01,progressDuration),0,1),1) end
 local observing=(status=='Eliminated' or status=='Escaped') and (phase=='Round' or phase=='Extraction')
 spectator.Visible=observing and not menu.Visible
 if observing then
  local candidates={}
  for _,other in ipairs(Players:GetPlayers()) do if other~=p and (other:GetAttribute('BreuState')=='Active' or other:GetAttribute('BreuState')=='Downed') and other.Character then table.insert(candidates,other) end end
  if #candidates>0 then
   spectateIndex=(spectateIndex-1)%#candidates+1;local other=candidates[spectateIndex];local target=other.Character:FindFirstChildOfClass('Humanoid')
   if target then camera.CameraSubject=target end;spectateLabel.Text='ASSISTINDO\n'..other.DisplayName
  else if h then camera.CameraSubject=h end;spectateLabel.Text='AGUARDANDO RESULTADO' end
 elseif h and camera.CameraSubject~=h then camera.CameraSubject=h end
 local npc=workspace:FindFirstChild('BreuHunter')
 if npc and npc.PrimaryPart then
  local speed=npc.PrimaryPart.AssemblyLinearVelocity.Magnitude
  local swing=math.sin(os.clock()*8)*math.min(speed/18,1)*.65
  for _,desc in ipairs(npc:GetDescendants()) do
   if desc:IsA('Motor6D') then
    if desc.Name=='Left Hip' or desc.Name=='Right Shoulder' then desc.Transform=CFrame.Angles(swing,0,0)
    elseif desc.Name=='Right Hip' or desc.Name=='Left Shoulder' then desc.Transform=CFrame.Angles(-swing,0,0) end
   end
  end
 end
 local targetFov=fov+(playing and p:GetAttribute('Sprinting') and 7 or 0)
 camera.FieldOfView=camera.FieldOfView+(targetFov-camera.FieldOfView)*math.min(1,dt*7)
end)
task.spawn(function()
 task.wait(.6)
 Tween:Create(intro,TweenInfo.new(.6),{BackgroundTransparency=1}):Play();Tween:Create(introLabel,TweenInfo.new(.6),{TextTransparency=1}):Play()
 task.wait(.6);intro:Destroy()
end)
