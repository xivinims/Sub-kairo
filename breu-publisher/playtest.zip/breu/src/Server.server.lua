local Players=game:GetService('Players')
local RS=game:GetService('ReplicatedStorage')
local SS=game:GetService('ServerStorage')
local Lighting=game:GetService('Lighting')
local RunService=game:GetService('RunService')
local Shared=RS:WaitForChild('Breu')
local Config=require(Shared.Config)
local Rules=require(Shared.Rules)
local Hunter=require(script.Parent.Hunter)
local Profile=require(script.Parent.Profile).start()
local net=Shared:WaitForChild('Action')
local feed=Shared:WaitForChild('Feedback')
local state=Shared:WaitForChild('State')
local lobby=workspace:WaitForChild('BreuLobby')
local templates=SS:WaitForChild('BreuMaps')
local states,stats,downAt,stamina,requestAt,carry,carryWeld,soloRescues={},{},{},{},{},{},{},{}
local activeMap,hunter,hunterAPI,context
local roundId=0
local phase='Lobby'
local repaired,required=0,0
local roundEnd=0
local interactions={}
local operations={}
local streamReady={}
local roundFinished=false
local rng=Random.new()
local function tell(p,message) if p.Parent then feed:FireClient(p,'Notice',message) end end
local function broadcast(message) feed:FireAllClients('Notice',message) end
local function setState(p,value)
 states[p]=value;p:SetAttribute('BreuState',value)
end
local function body(p)
 local c=p.Character
 return c,c and c:FindFirstChild('HumanoidRootPart'),c and c:FindFirstChildOfClass('Humanoid')
end
local function near(p,part,distance)
 local _,root,h=body(p)
 return part and part:IsA('BasePart') and root and h and h.Health>0 and (root.Position-part.Position).Magnitude <= distance
end
local function lineOfSight(p,part)
 local c,root=body(p);if not root then return false end
 local params=RaycastParams.new();params.FilterType=Enum.RaycastFilterType.Exclude;params.FilterDescendantsInstances={c}
 local hit=workspace:Raycast(root.Position,part.Position-root.Position,params)
 return not hit or hit.Instance==part or (part.Name=='HumanoidRootPart' and hit.Instance:IsDescendantOf(part.Parent))
end
local function release(p)
 local target=carry[p];if not target then return end
 if carryWeld[p] then carryWeld[p]:Destroy();carryWeld[p]=nil end
 local c,root,h=body(target)
 if c then
  for _,part in ipairs(c:GetDescendants()) do
   if part:IsA('BasePart') then
    local old=part:GetAttribute('BreuCarryCollision')
    if old~=nil then part.CanCollide=old;part:SetAttribute('BreuCarryCollision',nil) end
    local massless=part:GetAttribute('BreuCarryMassless');part.Massless=massless==true;part:SetAttribute('BreuCarryMassless',nil)
   end
  end
 end
 if h then h.PlatformStand=false end
 if root then local _,carrierRoot=body(p);if carrierRoot then root.CFrame=carrierRoot.CFrame*CFrame.new(3,0,0) end;pcall(function() root:SetNetworkOwnershipAuto() end) end
 target:SetAttribute('CarriedBy',nil);p:SetAttribute('Carrying',false);carry[p]=nil
end
local function releaseTarget(p)
 release(p)
 for carrier,target in pairs(carry) do if target==p then release(carrier) end end
end
local function stopOperation(p)
 local op=operations[p]
 if op then
  if op.object and op.object.Parent and op.object:GetAttribute('Operator')==p.UserId then op.object:SetAttribute('Operator',nil) end
  operations[p]=nil;feed:FireClient(p,'Progress',false)
 end
end
local function moveToLobby(p,offset)
 local c,root=body(p);if not root then return end
 task.spawn(function()
  pcall(function() p:RequestStreamAroundAsync(lobby.Spawn.Position,3) end)
  if p.Parent and p.Character==c and (states[p]=='Lobby' or states[p]=='Escaped') then
   root.CFrame=lobby.Spawn.CFrame+(offset or Vector3.new(0,3,0))
  end
 end)
end
local function toLobby(p)
 releaseTarget(p);stopOperation(p);setState(p,'Lobby')
 local c,root,h=body(p)
 local highlight=c and c:FindFirstChild('BreuDowned');if highlight then highlight:Destroy() end
 moveToLobby(p,Vector3.new(rng:NextNumber(-5,5),3,rng:NextNumber(-5,5)))
 if h then h.Health=h.MaxHealth;h.WalkSpeed=Config.WalkSpeed;h.JumpPower=50;h.PlatformStand=false end
 p:SetAttribute('Sprinting',false);p:SetAttribute('Crouching',false)
end
local function eliminate(p)
 releaseTarget(p);stopOperation(p);downAt[p]=nil;setState(p,'Eliminated')
 p:SetAttribute('Bleedout',0)
 local _,_,h=body(p);if h then h.Health=0 end
 tell(p,'Você ficou para trás. Assista aos sobreviventes ou espere a próxima rodada.')
end
local function down(p)
 if states[p]~='Active' then return end
 releaseTarget(p);stopOperation(p)
 local c,root,h=body(p);if not h then return end
 setState(p,'Downed');downAt[p]=os.clock();h.Health=1;h.WalkSpeed=3;h.JumpPower=0
 p:SetAttribute('Sprinting',false)
 local marker=Instance.new('Highlight');marker.Name='BreuDowned';marker.FillColor=Color3.fromRGB(225,156,76);marker.OutlineColor=Color3.new(1,1,1);marker.FillTransparency=.7;marker.Parent=c
 broadcast(p.DisplayName..' caiu. Alguém precisa ajudar!')
end
local function revive(p,actor)
 if states[p]~='Downed' then return end
 releaseTarget(p);downAt[p]=nil;setState(p,'Active');p:SetAttribute('Bleedout',0)
 local c,_,h=body(p);if h then h.Health=Config.ReviveHealth;h.WalkSpeed=Config.WalkSpeed;h.JumpPower=50 end
 local marker=c and c:FindFirstChild('BreuDowned');if marker then marker:Destroy() end
 if actor and stats[actor] then stats[actor].revives=stats[actor].revives+1 end
 tell(p,'De volta. Fica perto do grupo!')
end
local function damage(p,amount)
 if states[p]~='Active' then return end
 local _,_,h=body(p);if not h then return end
 if h.Health<=amount then down(p) else h:TakeDamage(amount) end
 feed:FireClient(p,'Hit',true)
end
local function noise(position)
 if context then context.noise={position=position,at=os.clock()} end
end
local function prompt(part,action,object,duration,callback)
 local pr=Instance.new('ProximityPrompt');pr.Name='BreuPrompt';pr.ActionText=action;pr.ObjectText=object
 pr.MaxActivationDistance=Config.InteractionDistance;pr.RequiresLineOfSight=true;pr.HoldDuration=0
 pr.KeyboardKeyCode=Enum.KeyCode.E;pr.GamepadKeyCode=Enum.KeyCode.ButtonX;pr.Parent=part
 interactions[pr]={part=part,duration=duration,callback=callback}
 pr.Triggered:Connect(function(p)
  if states[p]~='Active' or (phase~='Round' and phase~='Extraction') or not pr.Enabled then return end
  if not near(p,part,Config.InteractionDistance+1) or not lineOfSight(p,part) then return end
  if operations[p] then return end
  local owner=part:GetAttribute('Operator')
  if owner and owner~=p.UserId then tell(p,'Outra pessoa já está fazendo isso.');return end
  if duration<=0 then callback(p);return end
  part:SetAttribute('Operator',p.UserId)
  operations[p]={object=part,start=os.clock(),duration=duration,callback=callback,round=roundId}
  feed:FireClient(p,'Progress',{text=action,duration=duration})
 end)
 return pr
end
local function characterAdded(p,c)
 local h=c:WaitForChild('Humanoid',10);local root=c:WaitForChild('HumanoidRootPart',10)
 if not h or not root then return end
 h.UseJumpPower=true;h.WalkSpeed=Config.WalkSpeed
 h.Died:Connect(function()
  releaseTarget(p);stopOperation(p)
  if states[p]=='Active' or states[p]=='Downed' then setState(p,'Eliminated');downAt[p]=nil end
 end)
 task.wait(.2)
 if not p.Parent or p.Character~=c then return end
 if states[p]=='Active' or states[p]=='Downed' then setState(p,'Eliminated') end
 root.CFrame=lobby.Spawn.CFrame+Vector3.new(0,3,0)
end
Players.PlayerAdded:Connect(function(p)
 setState(p,'Lobby');stamina[p]=Config.StaminaMax;p:SetAttribute('Stamina',Config.StaminaMax);p:SetAttribute('Ready',false)
 p.CharacterAdded:Connect(function(c) characterAdded(p,c) end)
 task.spawn(function() Profile.load(p) end)
 if p.Character then task.spawn(characterAdded,p,p.Character) end
end)
Players.PlayerRemoving:Connect(function(p)
 releaseTarget(p);stopOperation(p);states[p]=nil;downAt[p]=nil;stats[p]=nil;stamina[p]=nil;requestAt[p]=nil;soloRescues[p]=nil
 Profile.remove(p)
end)
-- Connections are registered before the first yield in normal startup; cover existing Studio players too.
for _,p in ipairs(Players:GetPlayers()) do
 if not states[p] then
  setState(p,'Lobby');stamina[p]=100;p:SetAttribute('Ready',false);p.CharacterAdded:Connect(function(c) characterAdded(p,c) end)
  task.spawn(function() Profile.load(p) end)
  if p.Character then task.spawn(characterAdded,p,p.Character) end
 end
end
net.OnServerEvent:Connect(function(p,action,value)
 if type(action)~='string' or not ({Ready=true,Cancel=true,Sprint=true,Crouch=true,Flash=true,Carry=true,Revive=true})[action] then return end
 local now=os.clock();local last=requestAt[p] or {};requestAt[p]=last
 if now-(last[action] or -100)<.13 then return end;last[action]=now
 if action=='Ready' and type(value)=='boolean' then p:SetAttribute('Ready',value);return end
 if action=='Cancel' then stopOperation(p);return end
 if states[p]~='Active' then return end
 if action=='Sprint' and type(value)=='boolean' then p:SetAttribute('Sprinting',value);if value then p:SetAttribute('Crouching',false) end
 elseif action=='Crouch' and type(value)=='boolean' then p:SetAttribute('Crouching',value);if value then p:SetAttribute('Sprinting',false) end
 elseif action=='Flash' then
  if now-(p:GetAttribute('FlashAt') or -100)<Config.FlashCooldown then return end
  local c,root=body(p);if not root or not hunter then return end
  p:SetAttribute('FlashAt',now);p:SetAttribute('FlashReadyAt',workspace:GetServerTimeNow()+Config.FlashCooldown);noise(root.Position);feed:FireClient(p,'Flash',true)
  local offset=hunter.PrimaryPart.Position-root.Position
  if offset.Magnitude<30 and offset.Magnitude>0 and root.CFrame.LookVector:Dot(offset.Unit)>.45 and lineOfSight(p,hunter.PrimaryPart) then
   hunterAPI.stun(3);broadcast('O clarão desorientou o perseguidor!')
  end
 elseif action=='Carry' then
  if carry[p] then release(p);return end
  local _,root=body(p);if not root then return end
  for target,s in pairs(states) do
   local c,tr,h=body(target)
   if s=='Downed' and tr and not target:GetAttribute('CarriedBy') and (root.Position-tr.Position).Magnitude<7 and lineOfSight(p,tr) then
    stopOperation(target);carry[p]=target;target:SetAttribute('CarriedBy',p.UserId);p:SetAttribute('Carrying',true)
    h.PlatformStand=true
    for _,part in ipairs(c:GetDescendants()) do if part:IsA('BasePart') then part:SetAttribute('BreuCarryCollision',part.CanCollide);part:SetAttribute('BreuCarryMassless',part.Massless);part.CanCollide=false;part.Massless=true end end
    tr.CFrame=root.CFrame*CFrame.new(0,1,1.8);pcall(function() tr:SetNetworkOwner(nil) end)
    local weld=Instance.new('WeldConstraint');weld.Part0=root;weld.Part1=tr;weld.Parent=tr;carryWeld[p]=weld
    return
   end
  end
 elseif action=='Revive' then
  if operations[p] then return end
  local _,root=body(p);if not root then return end
  for target,s in pairs(states) do
   local _,tr=body(target)
   if Rules.canRevive(states[p],s) and tr and (root.Position-tr.Position).Magnitude<7 and not target:GetAttribute('CarriedBy') and lineOfSight(p,tr) then
    if tr:GetAttribute('Operator') then return end
    tr:SetAttribute('Operator',p.UserId)
    operations[p]={object=tr,start=now,duration=Config.ReviveSeconds,round=roundId,target=target,callback=function(actor) revive(target,actor) end}
    feed:FireClient(p,'Progress',{text='Ajudando '..target.DisplayName,duration=Config.ReviveSeconds});return
   end
  end
 end
end)
local function makeHunter(spawn,variant)
 local model=SS.BreuHunter:Clone();model.Parent=workspace;model:PivotTo(spawn.CFrame+Vector3.new(0,3,0))
 hunter=model
 context={config=Config,states=states,speed=variant.Speed,damage=damage,patrol=activeMap.Patrol:GetChildren(),barricades=activeMap.Barricades:GetChildren(),spawn=spawn,killY=-35}
 context.breakBarricade=function(b)
  local hp=(b:GetAttribute('Durability') or Config.BarricadeHealth)-1;b:SetAttribute('Durability',hp)
  noise(b.Position)
  if hp<=0 then b:SetAttribute('Closed',false);b:SetAttribute('Broken',true);b.CanCollide=false;b.Transparency=.85 end
 end
 hunterAPI=Hunter.start(model,context)
end
local function setupMap(map,variant)
 repaired=0
 local points=map.ObjectivePoints:GetChildren()
 for i=#points,2,-1 do local j=rng:NextInteger(1,i);points[i],points[j]=points[j],points[i] end
 local participating=0;for _,s in pairs(states) do if s=='Active' then participating=participating+1 end end
 required=Rules.requiredGenerators(participating,#points)
 for i,part in ipairs(points) do
  if i<=required then
   part.Transparency=0;part.Color=Color3.fromRGB(169,109,51)
   local light=part:FindFirstChildOfClass('PointLight');if light then light.Enabled=true end
   local pr
   pr=prompt(part,'Restaurar energia','Quadro '..i,Config.RepairSeconds,function(p)
    if part:GetAttribute('Repaired') then return end
    part:SetAttribute('Repaired',true);pr.Enabled=false;part.Color=Color3.fromRGB(124,189,158);repaired=repaired+1
    stats[p].repairs=stats[p].repairs+1;noise(part.Position)
    state:SetAttribute('Repaired',repaired);broadcast('Energia: '..repaired..'/'..required)
   end)
  else part.Transparency=1;part.CanCollide=false;local l=part:FindFirstChildOfClass('PointLight');if l then l.Enabled=false end end
 end
 for _,b in ipairs(map.Barricades:GetChildren()) do
  b:SetAttribute('Closed',false);b:SetAttribute('Durability',Config.BarricadeHealth);b.CanCollide=false;b.Transparency=.78
  local pr
  pr=prompt(b,'Fechar passagem','Barricada',1.2,function(p)
   if b:GetAttribute('Broken') then tell(p,'Essa barricada foi destruída.');return end
   local closed=not b:GetAttribute('Closed');b:SetAttribute('Closed',closed);b.CanCollide=closed;b.Transparency=closed and .08 or .78
   pr.ActionText=closed and 'Abrir passagem' or 'Fechar passagem';noise(b.Position)
  end)
 end
 local pushables=map:FindFirstChild('Pushables')
 if pushables then
  for _,box in ipairs(pushables:GetChildren()) do
   prompt(box,'Empurrar','Caixote móvel',.45,function(p)
    if box:GetAttribute('Moving') then return end
    local c,root=body(p);if not root then return end
    local d=Vector3.new(box.Position.X-root.Position.X,0,box.Position.Z-root.Position.Z)
    if d.Magnitude<.1 then return end
    d=d.Unit*5
    local params=RaycastParams.new();params.FilterType=Enum.RaycastFilterType.Exclude;params.FilterDescendantsInstances={box,c}
    local blocked=workspace:Blockcast(box.CFrame,box.Size*.94,d,params)
    local ground=workspace:Raycast(box.Position+d+Vector3.new(0,1,0),Vector3.new(0,-7,0),params)
    if blocked or not ground then tell(p,'Não há espaço para empurrar nessa direção.');return end
    box:SetAttribute('Moving',true);noise(box.Position)
    local tween=game:GetService('TweenService'):Create(box,TweenInfo.new(.6),{CFrame=box.CFrame+d});tween:Play()
    task.delay(.65,function() if box.Parent then box:SetAttribute('Moving',false) end end)
   end)
  end
 end
 for _,part in ipairs(map.Supplies:GetChildren()) do
  local pr
  pr=prompt(part,'Usar curativo','Primeiros socorros',2,function(p)
   local _,_,h=body(p)
   if h and h.Health<h.MaxHealth and not part:GetAttribute('Used') then
    part:SetAttribute('Used',true);h.Health=math.min(h.MaxHealth,h.Health+45);pr.Enabled=false;part.Transparency=1
   end
  end)
 end
 for _,exit in ipairs(map.Exits:GetChildren()) do
  exit.Transparency=.85;exit.CanCollide=false
  local pr=prompt(exit,'Embarcar','Resgate',1,function(p)
   if phase~='Extraction' or not exit:GetAttribute('Open') then return end
   if carry[p] then local target=carry[p];release(p);downAt[target]=nil;setState(target,'Escaped');moveToLobby(target,Vector3.new(3,3,0)) end
   releaseTarget(p);setState(p,'Escaped');moveToLobby(p)
   tell(p,'Você conseguiu. O resgate está seguro.')
  end)
  pr.Enabled=false
 end
 Lighting.FogEnd=variant.Fog;Lighting.ClockTime=1.8;Lighting.Brightness=1.7
end
local tickAt=0
RunService.Heartbeat:Connect(function(dt)
 tickAt=tickAt+dt;if tickAt<.1 then return end;local step=math.min(tickAt,.5);tickAt=0
 local now=os.clock()
 for p,s in pairs(states) do
  local _,root,h=body(p)
  if s=='Active' and h and root then
   local moving=h.MoveDirection.Magnitude>.1
   local sprint=p:GetAttribute('Sprinting') and moving and not carry[p] and not operations[p]
   local value=stamina[p] or 100
   value=math.clamp(value+(sprint and -Config.StaminaDrain or Config.StaminaRegen)*step,0,100)
   if value<=0 then p:SetAttribute('Sprinting',false);sprint=false end
   stamina[p]=value;p:SetAttribute('Stamina',math.floor(value))
   h.WalkSpeed=operations[p] and 5 or (carry[p] and 10 or (p:GetAttribute('Crouching') and Config.CrouchSpeed or (sprint and Config.SprintSpeed or Config.WalkSpeed)))
   if root.Position.Y < -35 then down(p);local sp=activeMap and activeMap.Spawns:GetChildren()[1];if sp then root.CFrame=sp.CFrame+Vector3.new(0,4,0) end end
  elseif s=='Downed' then
   local left=Config.DownSeconds-(now-(downAt[p] or now));p:SetAttribute('Bleedout',math.max(0,math.ceil(left)))
   -- A solo playtest has one rescue; co-op never grants automatic revives.
   if soloRescues[p] and now-(downAt[p] or now)>5 then soloRescues[p]=false;revive(p,nil);tell(p,'Segunda chance solo usada.')
   elseif left<=0 then eliminate(p) end
  end
 end
 for p,op in pairs(operations) do
  local _,_,operatorHumanoid=body(p)
  local valid=states[p]=='Active' and operatorHumanoid and operatorHumanoid.MoveDirection.Magnitude<.2 and op.round==roundId and near(p,op.object,Config.InteractionDistance+1) and lineOfSight(p,op.object)
  if op.target then valid=valid and states[op.target]=='Downed' and not op.target:GetAttribute('CarriedBy') end
  if not valid then stopOperation(p)
  elseif now-op.start>=op.duration then
   stopOperation(p);op.callback(p)
  end
 end
end)
local function publishPhase(value,seconds)
 phase=value;state:SetAttribute('Phase',value);state:SetAttribute('EndsAt',workspace:GetServerTimeNow()+seconds)
end
local function runRound()
 local ready={}
 for _,p in ipairs(Players:GetPlayers()) do
  local _,root,h=body(p)
  if p:GetAttribute('Ready')~=false and root and h and h.Health>0 then table.insert(ready,p) end
 end
 if #ready==0 then return end
 roundId=roundId+1;state:SetAttribute('Round',roundId);roundFinished=false
 local maps=templates:GetChildren();local selected=maps[((roundId-1)%#maps)+1]
 activeMap=selected:Clone();activeMap.Name='BreuActiveMap';activeMap.Parent=workspace
 local variant=Config.Variants[rng:NextInteger(1,#Config.Variants)]
 state:SetAttribute('Map',selected.Name);state:SetAttribute('Variant',variant.Name)
 local spawns=activeMap.Spawns:GetChildren()
 publishPhase('Preparing',10)
 for index,p in ipairs(ready) do
  streamReady[p]=nil
  local destination=spawns[(index-1)%#spawns+1].Position
  local thisRound=roundId
  feed:FireClient(p,'Transition',true)
  task.spawn(function()
   pcall(function() p:RequestStreamAroundAsync(destination,7) end)
   streamReady[p]=thisRound
  end)
 end
 local deadline=os.clock()+9
 repeat
  local all=true
  for _,p in ipairs(ready) do if p.Parent and streamReady[p]~=roundId then all=false end end
  if all then break end
  task.wait(.1)
 until os.clock()>=deadline
 for index,p in ipairs(ready) do
  if not p.Parent then
   -- Removed players are skipped by the guarded branch below.
  else
  releaseTarget(p);stopOperation(p);stats[p]={repairs=0,revives=0};setState(p,'Active');soloRescues[p]=#ready==1
  stamina[p]=100;p:SetAttribute('Bleedout',0);p:SetAttribute('Sprinting',false);p:SetAttribute('Crouching',false);p:SetAttribute('FlashAt',-100);p:SetAttribute('FlashReadyAt',0)
  local c,root,h=body(p);if h then h.Health=h.MaxHealth;h.PlatformStand=false;h.JumpPower=50 end
  local old=c and c:FindFirstChild('BreuDowned');if old then old:Destroy() end
  if root then root.CFrame=spawns[(index-1)%#spawns+1].CFrame+Vector3.new(0,3,0) end
  end
 end
 setupMap(activeMap,variant)
 state:SetAttribute('Required',required);state:SetAttribute('Repaired',0)
 publishPhase('Round',variant.Time);feed:FireAllClients('TransitionDone',true);roundEnd=os.clock()+variant.Time
 broadcast('Restaure '..required..' quadros de energia. O barulho denuncia você.')
 task.wait(6)
 if activeMap then makeHunter(activeMap.HunterSpawn,variant) end
 local result
 while not result do
  if phase=='Round' and repaired>=required then
   publishPhase('Extraction',Config.ExtractionSeconds);roundEnd=os.clock()+Config.ExtractionSeconds
   local exits=activeMap.Exits:GetChildren();local exit=exits[rng:NextInteger(1,#exits)]
   exit:SetAttribute('Open',true);exit.Transparency=.4;exit.Color=Color3.fromRGB(123,207,172)
   local light=exit:FindFirstChildOfClass('PointLight');if light then light.Enabled=true end
   exit.BreuPrompt.Enabled=true
   local beacon=Instance.new('Highlight');beacon.FillTransparency=.8;beacon.FillColor=Color3.fromRGB(132,223,183);beacon.Parent=exit
   state:SetAttribute('Exit',exit.Name);broadcast('Resgate disponível: '..exit.Name..'. Leve seus amigos!')
  end
  -- Give the solo emergency rescue time to run before declaring a total defeat.
  local hasSolo=false
  for p,s in pairs(states) do if s=='Downed' and soloRescues[p] then hasSolo=true end end
  if not hasSolo then result=Rules.result(states,roundEnd-os.clock()) end
  if os.clock()>=roundEnd then result='O resgate partiu' end
  task.wait(.3)
 end
 roundFinished=true
 if hunterAPI then hunterAPI.stop();hunterAPI=nil;hunter=nil end
 publishPhase('Results',Config.ResultSeconds);state:SetAttribute('Result',result)
 for _,p in ipairs(Players:GetPlayers()) do
  stopOperation(p);releaseTarget(p)
  if stats[p] then
   local escaped=states[p]=='Escaped'
   local award=Rules.reward(escaped,stats[p].repairs,stats[p].revives,Config)
   Profile.award(p,award)
   feed:FireClient(p,'Results',{title=result,escaped=escaped,coins=award,repairs=stats[p].repairs,revives=stats[p].revives})
  end
  downAt[p]=nil;toLobby(p)
 end
 task.wait(Config.ResultSeconds)
 if activeMap then activeMap:Destroy();activeMap=nil end
 context=nil;interactions={};stats={};soloRescues={};streamReady={}
 Lighting.FogEnd=600;Lighting.ClockTime=19
end
state:SetAttribute('Phase','Lobby');state:SetAttribute('Round',0)
game:BindToClose(function()
 for _,p in ipairs(Players:GetPlayers()) do Profile.save(p) end
end)
task.spawn(function()
 while true do
  if #Players:GetPlayers()>0 then
   publishPhase('Intermission',Config.Intermission)
   task.wait(Config.Intermission)
   local ok,err=xpcall(runRound,debug.traceback)
   if not ok then
    feed:FireAllClients('TransitionDone',true)
    warn('BREU round failed: '..tostring(err));broadcast('A rodada foi reiniciada. Seus dados estão preservados.')
    if hunterAPI then hunterAPI.stop();hunterAPI=nil end
    if activeMap then activeMap:Destroy();activeMap=nil end
    context=nil
    for _,p in ipairs(Players:GetPlayers()) do toLobby(p) end
   end
  else publishPhase('Lobby',0);task.wait(1) end
 end
end)
