-- Pure state rules: exercised outside Studio as well as used by the server.
local Rules = {}
function Rules.canAct(state)
 return state == 'Active'
end
function Rules.canRevive(actor, target)
 return actor == 'Active' and target == 'Downed'
end
function Rules.count(states)
 local active, down, escaped = 0, 0, 0
 for _, state in pairs(states) do
  if state == 'Active' then active = active + 1 end
  if state == 'Downed' then down = down + 1 end
  if state == 'Escaped' then escaped = escaped + 1 end
 end
 return active, down, escaped
end
function Rules.result(states, seconds)
 local active, down, escaped = Rules.count(states)
 if active == 0 then
  return escaped > 0 and 'Resgate concluído' or 'Ninguém voltou'
 end
 if seconds <= 0 then return 'O resgate partiu' end
 return nil
end
function Rules.requiredGenerators(players, available)
 return math.min(available, players <= 1 and 2 or 3)
end
function Rules.reward(escaped, repairs, revives, config)
 return (escaped and config.RewardEscape or 0) + repairs*config.RewardRepair + revives*config.RewardRevive
end
return Rules
