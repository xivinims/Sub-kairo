return {
 Version = '0.1.0-playtest', MaxPlayers = 12,
 Intermission = 25, RoundSeconds = 420, ExtractionSeconds = 65, ResultSeconds = 12,
 WalkSpeed = 14, SprintSpeed = 23, CrouchSpeed = 8,
 StaminaMax = 100, StaminaDrain = 19, StaminaRegen = 13,
 DownSeconds = 42, ReviveSeconds = 4, ReviveHealth = 55,
 HunterSpeed = 17, HunterSight = 105, HunterHearing = 145,
 HunterDamage = 38, HunterCooldown = 1.45, HunterRange = 5.8,
 Generators = 3, RepairSeconds = 7, BarricadeHealth = 4,
 InteractionDistance = 11, FlashCooldown = 24,
 RewardEscape = 100, RewardRepair = 20, RewardRevive = 25,
 Variants = {
  {Name = 'Apagão', Fog = 310, Speed = 17, Time = 420},
  {Name = 'Neblina fechada', Fog = 170, Speed = 16, Time = 450},
  {Name = 'Passos no escuro', Fog = 260, Speed = 19, Time = 390},
 },
}
