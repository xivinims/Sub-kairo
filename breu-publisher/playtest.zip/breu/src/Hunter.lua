local Players = game:GetService('Players')
local PathfindingService = game:GetService('PathfindingService')
local Hunter = {}
local function clearSight(a, b, ignore)
 local params = RaycastParams.new()
 params.FilterType = Enum.RaycastFilterType.Exclude
 params.FilterDescendantsInstances = ignore
 local hit = workspace:Raycast(a, b-a, params)
 return not hit
end
function Hunter.start(model, context)
 local human = model:FindFirstChildOfClass('Humanoid')
 local root = model.PrimaryPart
 local alive = true
 local stunUntil=0
 local destination, lastSeen, lastSeenAt, lastHit = nil, nil, 0, 0
 local pathPoints, pointIndex, pathAt, computing = {}, 2, 0, false
 local blockedConnection
 local pathGeneration = 0
 human.WalkSpeed = context.speed
 root:SetNetworkOwner(nil)
 local lastPosition, stuckAt = root.Position, os.clock()
 local function compute(goal)
  if computing then return end
  computing = true; pathAt = os.clock(); pathGeneration = pathGeneration + 1
  local generation = pathGeneration
  task.spawn(function()
   local path = PathfindingService:CreatePath({AgentRadius=2, AgentHeight=6, AgentCanJump=true, WaypointSpacing=5})
   local ok = pcall(function() path:ComputeAsync(root.Position,goal) end)
   if alive and generation == pathGeneration and ok and path.Status == Enum.PathStatus.Success then
    if blockedConnection then blockedConnection:Disconnect() end
    pathPoints = path:GetWaypoints(); pointIndex=2
    blockedConnection=path.Blocked:Connect(function(index)
     if index >= pointIndex then pathAt=0 end
    end)
   end
   computing=false
  end)
 end
 task.spawn(function()
  while alive and model.Parent and human.Health > 0 do
   local now=os.clock()
   human.WalkSpeed=now<stunUntil and 0 or context.speed
   local target, best = nil, math.huge
   for _,p in ipairs(Players:GetPlayers()) do
    local c=p.Character;local hrp=c and c:FindFirstChild('HumanoidRootPart')
    if context.states[p] == 'Active' and hrp then
     local distance=(hrp.Position-root.Position).Magnitude
     local sprint=p:GetAttribute('Sprinting') == true
     local visible=distance < context.config.HunterSight and clearSight(root.Position,hrp.Position,{model,c})
     local audible=sprint and distance < context.config.HunterHearing
     if (visible or audible) and distance < best then target=p;best=distance end
    end
   end
   if target then
    lastSeen=target.Character.HumanoidRootPart.Position; lastSeenAt=now; destination=lastSeen
    if now>=stunUntil and best < context.config.HunterRange and now-lastHit > context.config.HunterCooldown then
     local character=target.Character
     if clearSight(root.Position,character.HumanoidRootPart.Position,{model,character}) then
      lastHit=now;context.damage(target,context.config.HunterDamage)
     end
    end
   elseif lastSeen and now-lastSeenAt < 7 then destination=lastSeen
   elseif context.noise and now-context.noise.at < 9 then destination=context.noise.position
   elseif not destination or (destination-root.Position).Magnitude < 7 then
    local point=context.patrol[math.random(1,#context.patrol)]
    destination=point.Position
   end
   if destination then
    if now-pathAt > 1.2 then compute(destination) end
    local waypoint=pathPoints[pointIndex]
    if target and clearSight(root.Position,destination,{model,target.Character}) then
     human:MoveTo(destination)
    elseif waypoint then
     if (root.Position-waypoint.Position).Magnitude < 4 then pointIndex=pointIndex+1 end
     if waypoint.Action==Enum.PathWaypointAction.Jump then human.Jump=true end
     human:MoveTo(waypoint.Position)
    else
     -- No path: wait for a new solution, never walk directly through an unseen wall.
     human:MoveTo(root.Position)
    end
   end
   if (root.Position-lastPosition).Magnitude > 2 then lastPosition=root.Position;stuckAt=now end
   if now-stuckAt > 2.5 then
    human.Jump=true;pathAt=0;stuckAt=now
    for _,b in ipairs(context.barricades) do
     if b.Parent and b:GetAttribute('Closed') and (b.Position-root.Position).Magnitude < 9 then context.breakBarricade(b) end
    end
   end
   if root.Position.Y < context.killY then
    root.CFrame=context.spawn.CFrame+Vector3.new(0,4,0);pathPoints={};pathAt=0
   end
   task.wait(.18)
  end
 end)
 return {
  stun=function(seconds)
   if not alive then return end
   stunUntil=math.max(stunUntil,os.clock()+seconds);human.WalkSpeed=0
  end,
  stop=function()
   alive=false;pathGeneration=pathGeneration+1
   if blockedConnection then blockedConnection:Disconnect() end
   if model.Parent then model:Destroy() end
  end,
 }
end
return Hunter
